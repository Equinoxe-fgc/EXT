package uma.diana.nn_ext;

import java.util.Random;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.immersion.uhl.Launcher;

public class Seleccion extends Activity {
	
	public boolean entrada[]= new boolean [20]; // Coordinadores de selecci�n de posiciones de iconos
	public String cont_icono[] = new String [20]; //contenido icono
	public String cont_icono_y[] = new String [20];
	public boolean acierto_icono[]= new boolean[20];
	public boolean error_icono[]= new boolean[20];
	public String mensaje_texto = " ";
	
	public int contador_aciertos = 0;
	public boolean iniciar_reloj = false;
	
	public boolean   activar_respuesta = false;
	public int indice_icono =0; //marcador para hilo de figura incorrecta 
	public int indice_icono_error = 0;
	public boolean correcto = false;
	
		
	Random Math = new Random();
	
	
	public int numeros[] = new int[20];
	
	public int fase =0;  // Marcador de estado de fase
	
	 
	 private  Launcher launcher;
	 
	 public int estado_tb = 0;
	 public String icono, memoria_icono = "";
	 
	 
	 public boolean mensaje_tb = true;
	 
	 public int selecciones =0;
	 public boolean tipo_seleccion = true;
	 public boolean fase_activa = false;
	 public boolean act_menu = false;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_seleccion);
		
		
		
 	       
		Util.AM = getAssets();
		loadfase(0);
		Util.Cr_inicio.Iniciar();
		comienzo_test();
		
	    Util.ApplicationName = "NN_EXT";
	    if (!Util.MostrarTiempo){
			 TextView tiempo =  (TextView) findViewById(R.id.textView2);
			 tiempo.setTextColor(0); 
		 }
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_seleccion, menu);
		return true;
	}
	
	
	public void  visible_icono( int indice, int img){  // indice de icono, contenido de icono
		try{ 
		  if (indice == 0){
		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
	       dibujo.setImageResource(img);}
		  if (indice == 1){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
		       dibujo.setImageResource(img);}
		  if (indice == 2){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
		       dibujo.setImageResource(img);}
		  if (indice == 3){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
		       dibujo.setImageResource(img);}
		  if (indice == 4){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
		       dibujo.setImageResource(img);}
		  if (indice == 5){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
		       dibujo.setImageResource(img);}
		  if (indice == 6){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
		       dibujo.setImageResource(img);}
		  if (indice == 7){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
		       dibujo.setImageResource(img);}
		
		  if (indice == 8){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView9);
		       dibujo.setImageResource(img);}			
			  if (indice == 9){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView10);
			       dibujo.setImageResource(img);}
			  if (indice == 10){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView11);
			       dibujo.setImageResource(img);}
			  if (indice == 11){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView12);
			       dibujo.setImageResource(img);}
			  if (indice == 12){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView13);
			       dibujo.setImageResource(img);}
			  if (indice == 13){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView14);
			       dibujo.setImageResource(img);}
			  if (indice == 14){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView15);
			       dibujo.setImageResource(img);}
			  if (indice == 15){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView16);
			       dibujo.setImageResource(img);}
			
			 
        }catch (Exception e) 
        	{/*Toast.makeText(this, "falla  VISIBLE_ICONO",
                    Toast.LENGTH_SHORT).show();*/}
	
	
	
	
	}
	
	public int imagen ( String img){
		int entero=0;
		try{ 
		
		 if (img == "internet")
			 entero= R.drawable.internet;
		 if (img == "internet_y")
			 entero= R.drawable.internet_y;
 	     if (img == "facebook")
			entero= R.drawable.facebook;
 	     if (img== "facebook_y")
 	    	 entero=R.drawable.facebook_y;
		 if (img=="twitter")
			 entero = R.drawable.twitter;
		 if (img=="twitter_y")
			 entero = R.drawable.twitter_y;
		 
		 if (img=="linkedin")
			 entero =R.drawable.linkedin;
		 if (img=="linkedin_y")
			 entero =R.drawable.linkedin_y;
		 if (img=="wasapp")
			 entero =R.drawable.wasapp;
		 if (img=="wasapp_y")
			 entero =R.drawable.wasapp_y;
		 if (img=="phone")
			 entero =R.drawable.phone;
		 if (img=="phone_y")
			 entero =R.drawable.phone_y;
		 if (img=="sms")
			 entero =R.drawable.esemese;
		 if (img=="sms_y")
			 entero =R.drawable.esemese_y;
		 if (img=="email")
			 entero = R.drawable.email;
		 if (img=="email_y")
			 entero = R.drawable.email_y;
		 if (img=="line")
			 entero =R.drawable.line;
		 if (img=="line_y")
			 entero =R.drawable.line_y;
		 if (img=="googleplus_y")
			 entero = R.drawable.googleplus_y;
		 if (img=="googleplus")
			 entero = R.drawable.googleplus;
		 if (img=="store")
			 entero= R.drawable.store;
		 if (img=="store_y")
			 entero= R.drawable.store_y;
		 if (img=="talk")
			 entero= R.drawable.talk;
		 if (img=="talk_y")
			 entero= R.drawable.talk_y;
		 if (img=="calculadora")
			 entero=R.drawable.calculadora;
		 if (img=="calculadora_y")
			 entero=R.drawable.calculadora_y;
		 if (img=="calendario")
			 entero=R.drawable.calendario;
		 if (img=="calendario_y")
			 entero=R.drawable.calendario_y;
		 if (img=="reloj")
			 entero= R.drawable.reloj; 
		 if (img=="reloj_y")
			 entero= R.drawable.reloj_y; 
		 if (img=="camara")
			 entero= R.drawable.camara;
		 
		 if (img=="camara_y")
			 entero= R.drawable.camara_y;
		 
		 if (img=="def")
			 entero= R.drawable.def;
		 
		 if (img == "deficon")
			 entero = R.drawable.deficon;
		 if (img == "def_int")
			 entero = R.drawable.def_int;
		 
		 if (img == "def_int_y")
			 entero = R.drawable.def_int_y;
		 
		 if (img == "def_haptic_icon_disabled")
			 entero = R.drawable.def_haptic_icon_disabled;
		 
		 if (img == "def_haptic_icon_y")
			 entero = R.drawable.def_haptic_icon_y;
		 
		 if (img == "def_error")
			 entero = R.drawable.def_error;
		 
			 
		
		 
		}catch (Exception e) 
    	{/*Toast.makeText(this, "falla  IMAGEN",
                Toast.LENGTH_SHORT).show();*/}
		
		 return entero;
		
	}
	
public void loadfase( int estado_fase){
		
		TextView texto =  (TextView) findViewById(R.id.textView1);
		
		
		
		switch (estado_fase)
		{
		
		case 0:
			
			
			
			/*texto.setText("SELECCI�N DE POSICI�N");
	        cont_icono[0]= "internet";
	        cont_icono[1]="facebook";
	        cont_icono[2]= "twitter";
	        cont_icono[3]="linkedin";
	        cont_icono[4]="email";
	        cont_icono[5]="line";
	        cont_icono[6]="phone";
	        cont_icono[7]="sms";
	        cont_icono[8]="store";
	        cont_icono[9]="talk";
	        cont_icono[10]="googleplus";
	        cont_icono[11]="wasapp";
	        cont_icono[12]="calendario";
	        cont_icono[13]="camara";
	        cont_icono[14]="reloj";
	        cont_icono[15]="calculadora";
	        
	        cont_icono_y[0]= "internet_y";
	        cont_icono_y[1]="facebook_y";
	        cont_icono_y[2]= "twitter_y";
	        cont_icono_y[3]="likendin_y";
	        cont_icono_y[4]="email_y";
	        cont_icono_y[5]="line_y";
	        cont_icono_y[6]="phone_y";
	        cont_icono_y[7]="sms_y";
	        cont_icono_y[8]="store_y";
	        cont_icono_y[9]="talk_y";
	        cont_icono_y[10]="googleplus_y";
	        cont_icono_y[11]="wasapp_y";
	        cont_icono_y[12]="calendario_y";
	        cont_icono_y[13]="camara_y";
	        cont_icono_y[14]="reloj_y";
	        cont_icono_y[15]="calculadora_y";*/
			
			if (Util.DiferIconosHapt)
		        
	        {	
	        cont_icono[0]="internet";
	        cont_icono[1]="facebook";
	        cont_icono[2]= "twitter";
	        cont_icono[3]="linkedin";
	        cont_icono[4]="email";
	        cont_icono[5]="line";
	        cont_icono[6]="phone";
	        cont_icono[7]="sms";
	        cont_icono[8]="store";
	        cont_icono[9]="talk";
	        cont_icono[10]="googleplus";
	        cont_icono[11]="wasapp";
	        cont_icono[12]="calendario";
	        cont_icono[13]="camara";
	        cont_icono[14]="reloj";
	        cont_icono[15]="calculadora";
	        
	        cont_icono_y[0]= "internet_y";
	        cont_icono_y[1]="facebook_y";
	        cont_icono_y[2]= "twitter_y";
	        cont_icono_y[3]="linkedin_y";
	        cont_icono_y[4]="email_y";
	        cont_icono_y[5]="line_y";
	        cont_icono_y[6]="phone_y";
	        cont_icono_y[7]="sms_y";
	        cont_icono_y[8]="store_y";
	        cont_icono_y[9]="talk_y";
	        cont_icono_y[10]="googleplus_y";
	        cont_icono_y[11]="wasapp_y";
	        cont_icono_y[12]="calendario_y";
	        cont_icono_y[13]="camara_y";
	        cont_icono_y[14]="reloj_y";
	        cont_icono_y[15]="calculadora_y";
	        
	        
	     /*   Toast.makeText(this, "ATENCI�N: MODO DE VIBRACIONES DIFERENCIADAS. PULSE PARA COMENZAR ENTRENAMIENTO", 2000).show();
	        
	        */
	        
	        
	        }else{
	        	cont_icono[0]="internet";
	            cont_icono[5]="facebook";
	            cont_icono[10]= "twitter";
	            cont_icono[9]="linkedin";
	            cont_icono[6]="email";
	            cont_icono[2]="line";
	            cont_icono[4]="phone";
	            cont_icono[11]="sms";
	            cont_icono[8]="store";
	            cont_icono[3]="talk";
	            cont_icono[1]="googleplus";
	            cont_icono[7]="wasapp";
	            cont_icono[14]="calendario";
	            cont_icono[13]="camara";
	            cont_icono[12]="reloj";
	            cont_icono[15]="calculadora";
	            
	            cont_icono_y[0]= "internet_y";
	            cont_icono_y[5]="facebook_y";
	            cont_icono_y[10]= "twitter_y";
	            cont_icono_y[9]="linkedin_y";
	            cont_icono_y[6]="email_y";
	            cont_icono_y[2]="line_y";
	            cont_icono_y[4]="phone_y";
	            cont_icono_y[11]="sms_y";
	            cont_icono_y[8]="store_y";
	            cont_icono_y[3]="talk_y";
	            cont_icono_y[1]="googleplus_y";
	            cont_icono_y[7]="wasapp_y";
	            cont_icono_y[14]="calendario_y";
	            cont_icono_y[13]="camara_y";
	            cont_icono_y[12]="reloj_y";
	            cont_icono_y[15]="calculadora_y";
	        	
	     
	          /*  Toast.makeText(this, "ATENCI�N: MODO DE VIBRACIONES IGUALES. PULSE PARA COMENZAR ENTRENAMIENTO", 2000).show();
	            
	       	 */
	        }
	        
	    
	        
	        
	   
	        
	      
	       Util.Cr.Iniciar();
            int i=0;
			
			while( i < 16){
			  acierto_icono[i]=false;
			  error_icono[i] = false;
			  
			  
			  {visible_icono(i,imagen("def_int"));}
			  
			  i++;
			}
	        
			 i=0;
			
			while( i < 16){
			  entrada[i]=true;
			  i++;
			}
		  
		   break;
		}
		
}

public boolean onKeyDown(int keyCode, KeyEvent event) {
	// TODO Auto-generated method stub

	
	
	switch(keyCode){
		case KeyEvent.KEYCODE_CAMERA:
			/*Toast.makeText(this, "Obturador presionado",
                                                    Toast.LENGTH_SHORT).show();*/
			return true;
		case KeyEvent.KEYCODE_VOLUME_UP:
			/*Toast.makeText(this, "Volumen Up presionado",
                                                    Toast.LENGTH_SHORT).show();*/
			return true;
		case KeyEvent.KEYCODE_VOLUME_DOWN:
			/*Toast.makeText(this, "Volumen Down presionado",
                                                    Toast.LENGTH_SHORT).show();*/
			
		
			Util.Cr.Detener();
			Util.Cr_act.Detener();
			Util.Cr_i.Detener();
			Util.Cr_ns.Detener();
			Util.Cr_p.Detener();
			finish();
			Util.PlaySound("cortar");
			return true;
			
		case KeyEvent.KEYCODE_BACK:
			
			Util.Cr.Detener();
			Util.Cr_act.Detener();
			Util.Cr_i.Detener();
			Util.Cr_ns.Detener();
			Util.Cr_p.Detener();
			Util.PlaySound("cortar");
			finish();
			
			return true;
			
		case KeyEvent.KEYCODE_MENU:
			
			if(!activar_respuesta){ // Se inicia selecci�n
			// C�lculo de n�mero aleatorio sin repetir
				
				/*if(!iniciar_reloj){    //iniciar reloj
    				Util.Cr.Iniciar();
    				iniciar_reloj = true;
				}*/
				

				 if(!fase_activa & !act_menu){
					 
					
  	    			 /*fase_activa = true;*/
  	    			
					 Util.PlaySound("primera_seleccion");
					 act_menu = true;
  	    			Util.Cr_i.Iniciar();
  	    			mensaje_texto= "INICIO TEST. PRIMERA SELECCION";
  					mensaje_pantalla();
  	    			 
  	    			Util.LogWrLn();
	    			Util.Log("COMIENZA TEST");
	    			Util.LogWrLn();

	    			Util.Log_Excel_nl();
	    			Util.Log_Excel("COMIENZA TEST");
	    			Util.Log_Excel_nl();
	    			Util.Log_Excel_nl();
	    			
	    		   
	    			
	    			memorizar_icono();
	    			
	    			/*fase_activa = true;*/
	    		  
  	    		 }
		    	
		    	
			       
			   
			    
			    
			    
			    
			 /*     while(Util.Cr_i.Update()/1000 < 5){
                     Util.Sleep(50);
                 } */
			      
			    
			    
			   
			  
			     
                 
			
			}
			
			return true;
     	}
				
		
			return super.onKeyDown(keyCode, event);
	}
				
	
	public String requerimiento_aleatorio(){
		
		
		try{
        	launcher = new Launcher(this);
        }catch(RuntimeException re){}
    	
		String extmenu=""; 
			
		    numeros[0]= 10;
;			
		    int valorEntero = Math.nextInt(15) + 1;
		    
		    if (numeros[valorEntero] == 10){
		   
		    
		          for(int i=1; i < 17; i++ ){
		        	  
		        	  if (((valorEntero + i) > 16) && (contador_aciertos < 16)) {
		        		  valorEntero = 0;
		        		  i=1;
		        	  }
		        	  
		        	  if (numeros[valorEntero+i] == 10){
		        		  
		        	  }else{numeros[valorEntero+i] = 10;
		        	        valorEntero = valorEntero + i;
		        	        i = 17;
		        	        
		        	  }
		        	   
		          }
		        	  
		    }else{ 
		    	numeros[valorEntero]= 10;
		    	
		    }
		    	
		    	
		    	
		    /*Toast.makeText(this, "valor " + valorEntero, Toast.LENGTH_SHORT).show();*/  
		    
		   
		    extmenu= cont_icono[valorEntero - 1];
		    Util.PlaySound(extmenu);
		    Util.Cr_act.Iniciar();
		    activar_resp(); // uesta=true;
		   /*  vibraciones_iconos(extmenu);    //vibracion_requerimiento
		    switch (valorEntero){
		    
		    	case  1:
		    			
                    try{
                        Util.PlaySound("internet");
                        
	        		}catch (Exception e) 
	           		{}
		    		extmenu  = "internet";
		    	    break;
		    	
		    	case 2:
	    			
		    		try{  
		    		 Util.PlaySound("facebook");
	        		
	        		}catch (Exception e) 
	           		{}
		    		extmenu = "facebook";
		    		break;
		    	    
		    	case 3:
	    			
		    		 try{
		    		 Util.PlaySound("twitter");
		        		}catch (Exception e) 
		           		{}
		    		extmenu = "twitter";
		    		break;
		    	case 4:
	    			
		    		try{
		    			
		    			 Util.PlaySound("linkedin");
	        		}catch (Exception e) 
	           		{}
        	     
		    		extmenu = "linkedin";
		    	    break;
		    	case 5:
					
		    		try{
		    		 Util.PlaySound("email");
	        		}catch (Exception e) 
	           		{}
					extmenu = "email";
				    break;
		    	case 6:

		    		 try{
		    		 Util.PlaySound("line");
		        		}catch (Exception e) 
		           		{}
					extmenu = "line";
				    break;
		    	case  7:
	    			
		    		try{
		    		 Util.PlaySound("phone");
	        		}catch (Exception e) 
	           		{}
		    		extmenu = "phone";
		    	    break;
		    	
		    	case 8:
	    			
		    		try{
		    		 Util.PlaySound("sms");
	        		}catch (Exception e) 
	           		{}
		    		extmenu = "sms";
		    	    break;
		    	    
		    	case 9:
	    			
		    		try{
		    		 Util.PlaySound("store");
	        		}catch (Exception e) 
	           		{}
		    		extmenu = "store";
		    	    break;
		    	case 10:
	    			
		    		try{
		    		 Util.PlaySound("talk");
	        		}catch (Exception e) 
	           		{}
		    		extmenu = "talk";
		    	    break;
		    	case 11:
		    		
		    		try{
		    		 Util.PlaySound("googleplus");
	        		}catch (Exception e) 
	           		{}
					extmenu = "googleplus";
				    break;
				    
		    	case 12:

		    		 try{
		    		 Util.PlaySound("wasapp");
		        		}catch (Exception e) 
		           		{}
					extmenu = "wasapp";
				    break;
		    	case 13:
	    			
		    		try{
		    		 Util.PlaySound("calendario");
	        		}catch (Exception e) 
	           		{}
		    		extmenu = "calendario";
		    	    break;
		    	    
		    	case 14:
	    			
		    		try{
		    		 Util.PlaySound("camara");
	        		}catch (Exception e) 
	           		{}
		    		extmenu = "camara";
		    	    break;
		    	case 15:
	    			
		    		/*Util.uhl_PlayFile("pareja");
		    		
	        	    	 try{
	        	    	 Util.PlaySound("reloj");
			        		}catch (Exception e) 
			           		{}
	        	    	
	        	    	
		    		extmenu = "reloj";
		    	    break;
		    	case 16:
					
		    		try{// realizar operacion
		    		 Util.PlaySound("calculadora");
	        		}catch (Exception e) 
	           		{}
					extmenu = "calculadora";
				    break;
				    
		    }*/
		    
            return extmenu;			
			
			}

			
	

	
	
	
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		
		
		
		try{ 
			
			
	/*		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON, WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
			
*/

	/*	TextView salida = (TextView) findViewById(R.id.TextViewSalida);*/
		
		 
/*
		salida.append(evento.toString() );
		try
		  {Thread.sleep(1500);}
		catch (Exception e) 
   		{};
   		
   		salida.clearComposingText(); */
                     
		
    	try{
        	launcher = new Launcher(this);
        }catch(RuntimeException re){}
		
		
		String acciones[] = { "ACTION_DOWN", "ACTION_UP", "ACTION_MOVE", "ACTION_CANCEL","ACTION_OUTSIDE", "ACTION_POINTER_DOWN", "ACTION_POINTER_UP" , "ACTION_SCROLLL",  "ACTION_SCROLL"};
		int accion = event.getAction();

		int codigoAccion = accion & MotionEvent.ACTION_MASK;
		
		if (acciones[codigoAccion].equals("ACTION_MOVE"))
		{
		   
		}

	/*	salida.append(acciones[codigoAccion]);

		for (int i = 0; i < evento.getPointerCount(); i++) {

		salida.append(" puntero: "  + evento.getPointerId(i) + 
		" x:" + evento.getX(i) + " y:" + evento.getY(i));

		}

		salida.append("\n");*/
		
		
		
			
	   //Doble click
		
		if(acciones[codigoAccion].equals("ACTION_POINTER_DOWN") && activar_respuesta)
			
		{
			 if (estado_tb ==3)
		    	 if(Util.Cr.Update()/100 <2){
		  	    	 estado_tb = 4;
		  	    	 Util.Cr.Detener();
		  	    	 Util.Cr.Iniciar();
		  	    	adpulsacioncontinua();
		    	    }else {estado_tb = 1;
		    	           Util.Cr.Detener();}
			
			  
	     if (estado_tb==1){
	    	 estado_tb = 2;
	    	 Util.Cr.Detener();
	    	 Util.Cr.Iniciar();
	    	 
	     }
		}
	     
	    
		
       if(acciones[codigoAccion].equals("ACTION_POINTER_UP") && activar_respuesta)
			
		{
			
    	   if (estado_tb==2){
    		   
    	    if(Util.Cr.Update()/100 <2){
  	    	 estado_tb = 3;
  	    	 Util.Cr.Detener();
  	    	 Util.Cr.Iniciar();
    	    }else {estado_tb = 1;
    	          /* Util.Cr.Detener();*/}
    	   }
    	   
    	   
    	   
  	     if (estado_tb ==4 )
  	     {
  	    	 if(Util.Cr.Update()/100 <2){   // seleccion
  	  	    	
  	    		//Util.Cr.Detener();
  	    		 //estado_tb = 5;
  	    		 
  	    		if (!fase_activa){
  				  temporizador();   //inicio cronometro
  	   			  fase_activa = true;
  	  	      
  			    }
  	    		 
  	    		 if (fase_activa && activar_respuesta)
  	    		 comparador();
  	    		 
  	    	   
  	         }
  	    	 estado_tb = 1;
  	    	 mensaje_tb = false;
  	     }
	
		}
       
       // Fin doble Click
       
		
		/*salida.clearComposingText();*/
		if(acciones[codigoAccion].equals("ACTION_DOWN") && activar_respuesta)
			
		{
			
			  
			if ((estado_tb == 1 || estado_tb == 3 ) && event.getPointerCount() == 1)
			{
				 if (estado_tb ==3)
			    	 if(Util.Cr.Update()/100 <2){
			  	    	 estado_tb = 4;
			  	    	 Util.Cr.Detener();
			  	    	 Util.Cr.Iniciar();
			  	    	adpulsacioncontinua();
			    	    }else {estado_tb = 1;
			    	           Util.Cr.Detener();
					  	    	 }
				
				  
		     if (estado_tb==1){
		    	 estado_tb = 2;
		    	 Util.Cr.Detener();
		    	 Util.Cr.Iniciar();
		    	 
		     }
		     
		    
			}
		
		}
		
    if(acciones[codigoAccion].equals("ACTION_UP") && activar_respuesta)
			
		{
    		
    	
    	if ((estado_tb == 2 || estado_tb == 4 ) && event.getPointerCount() == 1 )
    	{
    	if (estado_tb==2){
 		   
    	    if(Util.Cr.Update()/100 <2){
  	    	 estado_tb = 3;
  	    	 Util.Cr.Detener();
  	    	 Util.Cr.Iniciar();
    	    }else {estado_tb = 1;
    	           Util.Cr.Detener();
		  	    	}
    	   }
  	    
    	if (estado_tb ==4)
  	     {
  	    	 if(Util.Cr.Update()/100 <2){   // seleccion
  	  	    	
  	    		 
  	    		if (!fase_activa){
  				  temporizador();   //inicio cronometro
  	   			  fase_activa = true;
  			    }
  	    	    if (fase_activa && activar_respuesta)
  	    		comparador();
  	    		 
  	    		estado_tb = 1;
  	    		mensaje_tb = false;
  	            }else{}
		
	 	  }
    	}   	
    	 
			  mensaje_tb = false;
		
		}
		
		
		
		if ((acciones[codigoAccion].equals("ACTION_MOVE") || acciones[codigoAccion].equals("ACTION_DOWN")) && event.getPointerCount() == 1 ){
			
			
			if (estado_tb <1){
				{
			
			if(activar_respuesta)
			seleccion(event);
			estado_tb = 1;
				}
			
			/*Util.Cr.Iniciar();*/
			}
		
			
			if(Util.Cr.Update()/100 >2 && estado_tb<3)
			{
			 if(activar_respuesta)
			 seleccion(event);
			 estado_tb = 1;
				
				/*seleccion();*/
			}		
				
			 if(Util.Cr.Update()/100 > 3)
				 {estado_tb = 1;
				 }
				
        	 
        	 
        	 
        	 
        	 
        	 
		return false;

		}
		
	     
	/*	if (estado_tb ==1 && mensaje_tb) {
			
 			if (Util.Cr.Update()/1000 > 0.75)
 			{   Util.PlaySound("bateria");
 				Util.Cr.Iniciar();
 				mensaje_tb = false;
 			} else { }
 				
		} */

		
		
		}catch (Exception e) 
    	{/*Toast.makeText(this, "falla  touch",
                Toast.LENGTH_SHORT).show();*/}
		return false;
		
	}
      
	public void comparador(){	 
		  
		    int h=0, hh=0;
		
			while(hh < 16){
				   if  (icono == cont_icono[hh])
					   {
					       h = hh;
					   };
				hh++;
			}
	   if (!acierto_icono[h]){	
		activar_respuesta = false;
 		 
	    	if (memoria_icono == icono)
	    	{
	    		
	    		/*correcto*/
	    	     int i=0;
	    	     correcto = true;
	    	     
	    	     
			 
			 Util.PlaySound("correcto");
			 
		     contador_aciertos++;
		     estado_tb =0 ;
		     
		     
                  while (i<16)
    			 {
    				 if (cont_icono[i]== memoria_icono){
    				    acierto_icono[i] = true;
    				    visible_icono(i,imagen(cont_icono[i]));
    				 }
    				 i++;
    			 }
                  
                Util.Log("   Click en icono: " + icono  + " (" + Util.Cr_p.GetStr() + ") Correcto!!!" );
    			Util.Log_Excel(icono + ";" + Util.Cr_p.GetStr() +";" + "correcto" );
    			Util.Log_Excel_nl();    
		     
		     Util.Cr_ns.Iniciar();
			
			 
			 
		     
		     if (contador_aciertos > 15)
		     {
		    	    final_test();
  	    			 
  	    			 
		     }else { 
		    	     Util.Cr_h.Detener();
		    	    nueva_seleccion();  }
		      
	    	}else
	    	{
	    	 
			 correcto = false;
			
			 contador_aciertos++;
			 
			 int i =0;
          
            	while (i<16)
			 {
				 if (cont_icono[i]== icono){
				    
				    /*visible_icono(i,imagen(cont_icono[i]));*/
					 visible_icono(i,imagen("def_error"));
				    Util.Cr.Iniciar();
				    indice_icono = i;
				   
				 }
				 
				 if (cont_icono[i]== memoria_icono)
				 {
					/*error_icono[i] = true;*/
					indice_icono_error = i;
				 }
				 i++;
				 
			 }
            	
            	
            	Util.Cr_ns.Iniciar();
            /*	nombrar();// hilo*/
            	
            	incorrecto(); // hilo
            	
            	/* Util.PlaySound("incorrecto");*/
            	
            	
            	Util.Log("   Click en icono: " + icono  + " (" + Util.Cr_p.GetStr() + ") incorrecto!!!" );
				Util.Log_Excel(icono + ";" + Util.Cr_p.GetStr() +";" + "incorrecto" );
				Util.Log_Excel_nl();
            	
            
			    mostrar_figura();
			    
			    i=0;
			    while (i<16)
			    	
			    {
			    	if (error_icono[i])
			    	{
			    		visible_icono(i,imagen("def_int"));
			    		/*visible_icono(i,imagen("def_error"));*/}
			    	i++;
			    }
			 
			 
			 if (contador_aciertos > 15)
		     {
		    	     final_test();
  	    			 
  	    			 
		     }else {
		    	    Util.Cr_h.Detener();
		    	    nueva_seleccion();  }
			   
	    	
	    	  }
	    	
	 
	    	}
  	
     }
		
	public void seleccion(MotionEvent event){
		
		
	/*if (icon.Name.equals("facebook"))*/
	if ((event.getX() < 175)  && (event.getY() < 400) && event.getY() > 150 && entrada[0])
	/*	if ((pixelX < 200)  && (pixelY < 300) && entrada_internet)*/
	  
	  if(!error_icono[0])	
	  {
		
		 tipo_seleccion = true;
		 seleccion_tb(0);
		 if (!acierto_icono[0])
		 {
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
  	     dibujo.setImageResource(R.drawable.def_int_y);
		 }else {
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
      	     dibujo.setImageResource(imagen(cont_icono_y[0]));
    		 }
		  
	         /*try{	 
	    		 launcher.stop();
	    		 mediaplayer.start();
	    		 launcher.play(50);
	    		
        		}catch (Exception e) 
           		{} */
		    
  	     
  	     
  	        
		     icono = cont_icono[0];
		     
	    	/* mensaje_pantalla(icono);*/
	    	 
	    	/* Util.Cr_h.Iniciar();*/
				 mensaje_tb = true;
	    	 
				 entrada[0]= false;
	        	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
	         	     dibujo.setImageResource(imagen("def_error"));}
		
		
		 
	 if    (!((event.getX() < 175)  && (event.getY() < 400) && (event.getY() > 150)) )
	/*	if(!((pixelX < 200)  && (pixelY < 300)))*/
	 {
		 if (!error_icono[0]){
		 if (!acierto_icono[0]){
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
  	      dibujo.setImageResource(R.drawable.def_int);}else{
  	    	ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
    	      dibujo.setImageResource(imagen(cont_icono[0]));}}else {ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
    	      														 dibujo.setImageResource(imagen("def_error"));}
  	    	  
  	      
  	    	  
		 
		
		 
		    	 entrada[0] = true; 
	 }
			
  /*  if (icon.Name.equals("twitter"))*/
	
	if ((event.getX() > 175)  && (event.getX() <350) && (event.getY() < 400) && (event.getY() > 150) && entrada[1])
	/*	if ((pixelX> 200)  && (pixelX <400) && (pixelY< 300) && entrada_facebook)*/
		if(!error_icono[1])	
	     {
		 
		 tipo_seleccion = true;
		 seleccion_tb(1);
		 if (!acierto_icono[1])
		 {
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
  	     dibujo.setImageResource(R.drawable.def_int_y);
		 }else {
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
      	     dibujo.setImageResource(imagen(cont_icono_y[1]));
    		 }
		   
	    	/*try{launcher.stop();
	    	    mediaplayer.start();
	    		 launcher.play(30);
	    		
        		
        		}catch (Exception e) 
           		{}*/
		 
	    	 icono = cont_icono[1];
	    	 
	    	 /*mensaje_pantalla(icono);*/
	    	 entrada[1] = false;
	        	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
	         	     dibujo.setImageResource(imagen("def_error"));}
	
	 if    (!((event.getX() > 175)  && (event.getX() <350) && (event.getY() < 400) && (event.getY() > 150)) )
	/*	if (!((pixelX> 200)  && (pixelX <400) && (pixelY< 300)))*/
	 {   
		 if(!error_icono[1]){
		 if (!acierto_icono[1]){
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
 	      dibujo.setImageResource(R.drawable.def_int);}else{
 	    	ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
   	      dibujo.setImageResource(imagen(cont_icono[1]));}}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
   	      								dibujo.setImageResource(imagen("def_error"));}
	 
	 
    	 entrada[1] = true; }
	 
	 
	/* if (icon.Name.equals("linkedin")) */
	if ((event.getX() > 350)  && (event.getX() <525) && (event.getY() < 400) && (event.getY() > 150) && entrada[2])
/* 	if ((pixelX > 400)  && (pixelX <600) && (pixelY< 300) && entrada_twitter)*/
    
		if(!error_icono[2])	
	{
		tipo_seleccion = true;
		seleccion_tb(2);
		if (!acierto_icono[2])
		 {
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
 	     dibujo.setImageResource(R.drawable.def_int_y);
		 }else {
   		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
     	     dibujo.setImageResource(imagen(cont_icono_y[2]));
   		 }
		/*try{launcher.stop();
		    mediaplayer.start(); 
    		launcher.play(91);
    		
    		}catch (Exception e) 
       		{}*/
		 
    	 icono = cont_icono[2];
    	
    	 /*mensaje_pantalla(icono);*/
    	 entrada[2] = false;
	 
     }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
	     dibujo.setImageResource(imagen("def_error"));}
	
	if    (!((event.getX() > 350)  && (event.getX() <525) && (event.getY() < 400) && (event.getY() > 150)) )
	/*	 if (!((pixelX > 400)  && (pixelX <600) && (pixelY< 300)))*/
	{     if (!error_icono[2]){
		  if (!acierto_icono[2]){
		     ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
	         dibujo.setImageResource(R.drawable.def_int);}else{
	    	 ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
	         dibujo.setImageResource(imagen(cont_icono[2]));}}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
	         														dibujo.setImageResource(imagen("def_error"));}
	
	
    	 entrada[2] = true; }
	
	 
    	 
/*  if (icon.Name.equals("wasapp")) */
	 if ((event.getX() > 525)  && (event.getX() <700) && (event.getY() < 400) && (event.getY() > 150) && entrada[3])
		 if(!error_icono[3])		
	 {
		 tipo_seleccion = true;
		 seleccion_tb(3);
		 if (!acierto_icono[3])
		 {
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
  	     dibujo.setImageResource(R.drawable.def_int_y);
		 }else {
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
      	     dibujo.setImageResource(imagen(cont_icono_y[3]));
    		 }
		/* try{launcher.stop();
		      mediaplayer.start();
    		 launcher.play(40);
    		
    		}catch (Exception e) 
       		{}*/
		
    	 icono = cont_icono[3];
    	 
    	
    	/* mensaje_pantalla(icono);*/
    	 entrada[3] = false;
    	 
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
    	     dibujo.setImageResource(imagen("def_error"));}  	     
		
	 if    (!((event.getX() > 525)  && (event.getX() <700) && (event.getY() < 400) && (event.getY() > 150)) )
	 {   if (!error_icono[3]){
		 if (!acierto_icono[3]){
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
      	      dibujo.setImageResource(R.drawable.def_int);}else{
      	    	ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
        	      dibujo.setImageResource(imagen(cont_icono[3]));}}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
        	                                                        dibujo.setImageResource(imagen("def_error"));}
		 
		 entrada[3] = true; }
	 
	 /*if (icon.Name.equals("phone"))*/
	 if ((event.getX() > 0)  && (event.getX() <175) && (event.getY() > 400 ) && (event.getY() < 700)  && entrada[4])
		 if(!error_icono[4])		  
     {
		 tipo_seleccion = true;
		 seleccion_tb(4);
		 if (!acierto_icono[4])
		 {
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
  	     dibujo.setImageResource(R.drawable.def_int_y);
		 }else {
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
      	     dibujo.setImageResource(imagen(cont_icono_y[4]));
    		 }
		/* try{launcher.stop();
			 launcher.play(35);
			 mediaplayer.start();
    		}catch (Exception e) 
       		{}*/
		
    	 icono = cont_icono[4];
    	
    	/* mensaje_pantalla(icono);*/
    	 entrada[4] = false;
    
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
    	     dibujo.setImageResource(imagen("def_error"));}
	 
	 if    (!((event.getX() > 0)  && (event.getX() <175) && (event.getY() > 400 ) && (event.getY() < 700) ) )
	 {
		 if (!error_icono[4]){
		 if (!acierto_icono[4]){
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
 	      dibujo.setImageResource(R.drawable.def_int);}else{
 	    	ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
   	      dibujo.setImageResource(imagen(cont_icono[4]));}}else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
	      dibujo.setImageResource(imagen("def_error"));}
	 
	 
		 entrada[4] = true; }
	 
	/* if (icon.Name.equals("sms"))*/
	 if ((event.getX() > 175)  && (event.getX() <350) && (event.getY() > 400 ) && (event.getY() < 700)  && entrada[5])
		 if(!error_icono[5])	  
     {
		 tipo_seleccion = true;
		 seleccion_tb(5);
		 if (!acierto_icono[5])
		 {
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
  	     dibujo.setImageResource(R.drawable.def_int_y);
		 }else {
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
      	     dibujo.setImageResource(imagen(cont_icono_y[5]));
    		 }
		 
    	/*try{launcher.stop();
    	    mediaplayer.start();
    		launcher.play(77);
    		
    		}catch (Exception e) 
       		{}*/
		
    	 icono = cont_icono[5];
    	
    	 /*mensaje_pantalla(icono);*/
    	 entrada[5] = false;
    
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
    	     dibujo.setImageResource(imagen("def_error"));}
	 
	 
	 if    (!((event.getX() > 175)  && (event.getX() <350) && (event.getY() > 400 ) && (event.getY() < 700))) 
	 {	 entrada[5] = true; 
	 if (!error_icono[5]){
	 if (!acierto_icono[5]){
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
  	      dibujo.setImageResource(R.drawable.def_int);}else{
  	    	ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
    	      dibujo.setImageResource(imagen(cont_icono[5]));}}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
    	      dibujo.setImageResource(imagen("def_error"));}
	 
	 }
	 
	 
	 /* if (icon.Name.equals("email"))*/
	 if ((event.getX() > 350)  && (event.getX() <525) && (event.getY() > 400 ) && (event.getY() < 700)  && entrada[6])
		 if(!error_icono[6])	  
     {
		 tipo_seleccion = true;
		 seleccion_tb(6);
		 if (!acierto_icono[6])
		 {
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
  	     dibujo.setImageResource(R.drawable.def_int_y);
		 }else {
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
      	     dibujo.setImageResource(imagen(cont_icono_y[6]));
    		 }
		
    	/* try{launcher.stop();
    	 mediaplayer.start();
    		 launcher.play(67);
    		
    		}catch (Exception e) 
       		{}*/
		 
    	 icono = cont_icono[6];
    	
    	 /*mensaje_pantalla(icono);*/
    	 entrada[6] = false;
    
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
    	     dibujo.setImageResource(imagen("def_error"));}
	 
	 if    (!((event.getX() > 350)  && (event.getX() <525) && (event.getY() > 400 ) && (event.getY() < 700)) )
	 {   if (!error_icono[6]){
		 if (!acierto_icono[6]){
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
      	      dibujo.setImageResource(R.drawable.def_int);}else{
      	    	ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
        	      dibujo.setImageResource(imagen(cont_icono[6]));}}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
        	      dibujo.setImageResource(imagen("def_error"));}
	 
	 
		 entrada[6] = true; }
	 
	 /* if (icon.Name.equals("line"))*/
	 if ((event.getX() > 525)  && (event.getX() <700) && (event.getY() > 400 ) && (event.getY() < 700)  && entrada[7])
		 if(!error_icono[7])	
     {
		 tipo_seleccion = true;
		 seleccion_tb(7);
		 if (!acierto_icono[7])
		 {
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
  	     dibujo.setImageResource(R.drawable.def_int_y);
		 }else {
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
      	     dibujo.setImageResource(imagen(cont_icono_y[7]));
    		 }
		/* try{launcher.stop();
		    mediaplayer.start();
    		 launcher.play(76);
    		
    		}catch (Exception e) 
       		{}*/
		 
    	 icono = cont_icono[7];
    	 
    	/* mensaje_pantalla(icono);*/
    	 entrada[7] = false;
    
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
    	     dibujo.setImageResource(imagen("def_error"));}
	 
	 if    (!((event.getX() > 525)  && (event.getX() <700) && (event.getY() > 400 ) && (event.getY() < 700)) )
    	 
	 {	  if (!error_icono[7]){
		 if (!acierto_icono[7]){
		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
 	      dibujo.setImageResource(R.drawable.def_int);}else{
 	    	ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
   	      dibujo.setImageResource(imagen(cont_icono[7]));}}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
	                                                             dibujo.setImageResource(imagen("def_error"));}
	 
	 	entrada[7]= true; }
	 
	 
	 //*****************************************************************
	 
	 
	 
	 /*if (icon.Name.equals("googleplus"))*/
		if ((event.getX() < 175)   && (event.getY() > 700) && (event.getY() < 1000) && entrada[8])
			if(!error_icono[8])	 
		{
			tipo_seleccion = false;
			seleccion_tb(8);
			if (fase<2){
			if (!acierto_icono[8]){
			ImageView dibujo =  (ImageView) findViewById(R.id.imageView9);
     	   dibujo.setImageResource(R.drawable.def_int_y);}
			}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView9);
				dibujo.setImageResource(imagen(cont_icono_y[8]));}
			
			/*try{
	    		 launcher.stop();
	    		 mediaplayer.start();
	    		 launcher.play(50);
	    		
        		
        		}catch (Exception e) 
           		{}*/
			 
	    	 icono = cont_icono[8];
	    	
	    	/* mensaje_pantalla(icono);*/
	    	 entrada[8] = false;
	    	
	        	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView9);
	         	     dibujo.setImageResource(imagen("def_error"));}
		
		
		 
		   if    (!((event.getX() < 175)  && (event.getY() > 700) && (event.getY() < 1000)) )
		   { 
			   if (!error_icono[8]){
			   if (!acierto_icono[8]){
      		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView9);
         	   dibujo.setImageResource(R.drawable.def_int);}else{
      		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView9);
          	   dibujo.setImageResource(imagen(cont_icono[8]));
         	   }
         	   
      		   
      	   }else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView9);
      	   dibujo.setImageResource(imagen("def_error"));}
    	      
    	      
    	      
		    	 entrada[8] = true; }
		    
			
  /*  if (icon.Name.equals("wifi"))*/
	
	if ((event.getX() > 175)  && (event.getX() <350) && (event.getY() > 700) && (event.getY() < 1000) && entrada[9])
		if(!error_icono[9])	     
	{
		tipo_seleccion = false;
		seleccion_tb(9);
		if (fase<2){
		if (!acierto_icono[9]){
			ImageView dibujo =  (ImageView) findViewById(R.id.imageView10);
     	   dibujo.setImageResource(R.drawable.def_int_y);}
		}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView10);
		dibujo.setImageResource(imagen(cont_icono_y[9]));}
		
		
		/* try{  launcher.stop();
		      mediaplayer.start();
	    	  launcher.play(30);
        		
        		}catch (Exception e) 
           		{}*/
		 	
	    	 icono = cont_icono[9];
	    	 
	    /*	 mensaje_pantalla(icono);*/
	    	 entrada[9] = false;
	        	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView10);
	         	     dibujo.setImageResource(imagen("def_error"));
	         	     }
	
	 if    (!((event.getX() > 175)  && (event.getX() <350) && (event.getY() > 700) && (event.getY() < 1000)) )
    	 {entrada[9] = true;
    	 
    	 if (!error_icono[9]){
			   if (!acierto_icono[9]){
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView10);
       	   dibujo.setImageResource(R.drawable.def_int);}else{
    		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView10);
        	   dibujo.setImageResource(imagen(cont_icono[9]));
       	   }
       	   
    		   
    	   }else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView10);
    	   dibujo.setImageResource(imagen("def_error"));}
  	      
    	 }
	 
	/* if (icon.Name.equals("update")) */
	if ((event.getX() > 350)  && (event.getX() <525) && (event.getY() > 700) && (event.getY() < 1000) && entrada[10])
		if(!error_icono[10])	       
     {  tipo_seleccion = false;
		seleccion_tb(10);
		if (fase<2){
    		if (!acierto_icono[10]){
    			ImageView dibujo =  (ImageView) findViewById(R.id.imageView11);
         	   dibujo.setImageResource(R.drawable.def_int_y);}
    		}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView11);
			dibujo.setImageResource(imagen(cont_icono_y[10]));}
		/*try{launcher.stop();
	    	mediaplayer.start();
    	    launcher.play(91);
    		
    		}catch (Exception e) 
       		{}*/
		 
    	 icono = cont_icono[10];
    	
    	/* mensaje_pantalla(icono);*/
    	 entrada[10] = false;
	 
     }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView11);
	     dibujo.setImageResource(imagen("def_error"));}
	
	 if    (!((event.getX() > 350)  && (event.getX() <525) && (event.getY() > 700) && (event.getY() < 1000)) )
	 {   if (!error_icono[10]){
		   if (!acierto_icono[10]){
    		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView11);
       	   dibujo.setImageResource(R.drawable.def_int);}else{
    		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView11);
        	   dibujo.setImageResource(imagen(cont_icono[10]));
       	   }
       	   
    		   
    	   }else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView11);
    	   dibujo.setImageResource(imagen("def_error"));}
  	      
		   
		   
	
	         
	         
		 entrada[10] = true; }
	
	 
    	 
/*  if (icon.Name.equals("talk")) */
	 if ((event.getX() > 525)  && (event.getX() <700) && (event.getY() > 700) && (event.getY() < 1000) && entrada[11])
		 if(!error_icono[11])			
        {
		 tipo_seleccion = false;
		 seleccion_tb(11);
		 if (fase<2){
     		if (!acierto_icono[11]){
     			ImageView dibujo =  (ImageView) findViewById(R.id.imageView12);
          	   dibujo.setImageResource(R.drawable.def_int_y);}
     		}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView12);
				dibujo.setImageResource(imagen(cont_icono_y[11]));}
		
		/* try{launcher.stop();
		     mediaplayer.start();
    		 launcher.play(40);
    		
    		}catch (Exception e) 
       		{}*/
		 
    	 icono = cont_icono[11];
   
    	/* mensaje_pantalla(icono);*/
    	 entrada[11] = false;
    	 
     	    } else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView12);
    	     dibujo.setImageResource(imagen("def_error"));} 	     
		
	 if    (!((event.getX() > 525)  && (event.getX() <700) && (event.getY() > 700) && (event.getY() < 1000)) )
	 { 
		 if (!error_icono[11]){
			   if (!acierto_icono[11]){
          		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView12);
             	   dibujo.setImageResource(R.drawable.def_int);}else{
          		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView12);
              	   dibujo.setImageResource(imagen(cont_icono[11]));
             	   }
             	   
          		   
          	   }else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView12);
          	   dibujo.setImageResource(imagen("def_error"));}
        	      
		 entrada[11] = true; }
	
	  /*if (icon.Name.equals("bateria"))*/
	 if ((event.getX() > 0)  && (event.getX() <175) && (event.getY() > 1000 )  && entrada[12])
		 if(!error_icono[12])	
     {	tipo_seleccion = false;
		seleccion_tb(12);
		 
		if (fase<2){
    		if (!acierto_icono[12]){
    			ImageView dibujo =  (ImageView) findViewById(R.id.imageView13);
         	   dibujo.setImageResource(R.drawable.def_int_y);}
    		}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView13);
			dibujo.setImageResource(imagen(cont_icono_y[12]));}
		
    	/* try{launcher.stop();
    	     mediaplayer.start();
    		 launcher.play(22);
    		
    		}catch (Exception e) 
       		{}*/
		 
    	 icono = cont_icono[12];
    	 
    	/* mensaje_pantalla(icono); */
    	 entrada[12] = false;
    
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView13);
    	     dibujo.setImageResource(imagen("def_error"));}
	 
	 if    (!((event.getX() > 0)  && (event.getX() <175) &&  (event.getY() > 1000 ) ) )
	 { entrada[12]= true; 
	 
	 
	 if (!error_icono[12]){
		   if (!acierto_icono[12]){
      		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView13);
         	   dibujo.setImageResource(R.drawable.def_int);}else{
      		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView13);
          	   dibujo.setImageResource(imagen(cont_icono[12]));
         	   }
         	   
      		   
      	   }else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView13);
      	   dibujo.setImageResource(imagen("def_error"));}
    	      
	 }
	 
	/* if (icon.Name.equals("calendario"))*/
	 if ((event.getX() > 175)  && (event.getX() <350) &&  (event.getY() > 1000 )  && entrada[13])
	 if(!error_icono[13])	
     {
		 tipo_seleccion = false;
		 seleccion_tb(13);
		 if (fase<2){
     		if (!acierto_icono[13]){
     			ImageView dibujo =  (ImageView) findViewById(R.id.imageView14);
          	   dibujo.setImageResource(R.drawable.def_int_y);}
     		}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView14);
				dibujo.setImageResource(imagen(cont_icono_y[13]));}
		/* try{launcher.stop();
		     mediaplayer.start();
    	 	 launcher.play(53);
    		
    		}catch (Exception e) 
       		{}*/
		 
    	 icono = cont_icono[13];
    	 
    /*	 mensaje_pantalla(icono); */
    	 entrada[13] = false;
    
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView14);
    	     dibujo.setImageResource(imagen("def_error"));}
	 
	 
	 if    (!((event.getX() > 175)  && (event.getX() <350) &&  (event.getY() > 1000 ))) 
	 {
		 if (!error_icono[13]){
			   if (!acierto_icono[13]){
          		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView14);
             	   dibujo.setImageResource(R.drawable.def_int);}else{
          		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView14);
              	   dibujo.setImageResource(imagen(cont_icono[13]));
             	   }
             	   
          		   
          	   }else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView14);
          	   dibujo.setImageResource(imagen("def_error"));}
        	      
		 
		entrada[13] = true;} 
	 
	 
	 /* if (icon.Name.equals("reloj"))*/
	 if ((event.getX() > 350)  && (event.getX() <525) &&  (event.getY() > 1000 )  && entrada[14])
     if(!error_icono[14])	
     {
		 tipo_seleccion = false;
		 seleccion_tb(14);
		 if (fase<2){
     		if (!acierto_icono[14]){
     			ImageView dibujo =  (ImageView) findViewById(R.id.imageView15);
          	   dibujo.setImageResource(R.drawable.def_int_y);}
     		}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView15);
				dibujo.setImageResource(imagen(cont_icono_y[14]));}
		 
		/* try{launcher.stop();
	     	 mediaplayer.start();
    		 launcher.play(47);
    		
    		}catch (Exception e) 
       		{}*/
		 
		 
    	 icono = cont_icono[14];
    	
    	/* mensaje_pantalla(icono);*/
    	 entrada[14] = false;
    
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView15);
    	     dibujo.setImageResource(imagen("def_error"));}
	 
	 if    (!((event.getX() > 350)  && (event.getX() <525) &&  (event.getY() > 1000 )) )
	 { 
		 if (!error_icono[14]){
			   if (!acierto_icono[14]){
          		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView15);
             	   dibujo.setImageResource(R.drawable.def_int);}else{
          		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView15);
              	   dibujo.setImageResource(imagen(cont_icono[14]));
             	   }
             	   
          		   
          	   }else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView15);
          	   dibujo.setImageResource(imagen("def_error"));}
        	      
	         
	         
	         
    	 entrada[14] = true; }
	 
	 /* if (icon.Name.equals("instagram"))*/
	   if ((event.getX() > 525)  && (event.getX() <700) &&  (event.getY() > 1000 )  && entrada[15])
		 if(!error_icono[15])	
	     {
		 tipo_seleccion = false;
		 seleccion_tb(15);
		 if (fase<2){
     		if (!acierto_icono[15]){
     			ImageView dibujo =  (ImageView) findViewById(R.id.imageView16);
          	   dibujo.setImageResource(R.drawable.def_int_y);}
     		}else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView16);
				dibujo.setImageResource(imagen(cont_icono_y[15]));}
		 
    	 icono = cont_icono[15];
    	 
    	/* mensaje_pantalla(icono);*/
    	 entrada[15] = false;
    
     	    }else{ ImageView dibujo =  (ImageView) findViewById(R.id.imageView16);
    	     dibujo.setImageResource(imagen("def_error"));}
		 
	 
	 if    (!((event.getX() > 525)  && (event.getX() <700) &&(event.getY() > 1000 )) )
	 {
		 
		 entrada[15] = true; 
    	 
		 if (!error_icono[15]){
			   if (!acierto_icono[15]){
          		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView16);
             	   dibujo.setImageResource(R.drawable.def_int);}else{
          		   ImageView dibujo =  (ImageView) findViewById(R.id.imageView16);
              	   dibujo.setImageResource(imagen(cont_icono[15]));
             	   }
             	   
          		   
          	   }else{ImageView dibujo =  (ImageView) findViewById(R.id.imageView16);
          	   dibujo.setImageResource(imagen("def_error"));}
        	      
	 }    
	 
	 
	}
       
       
	
	 public void seleccion_tb( int i)
	 
	 {  try{
		 estado_tb = 1;
		 Util.Cr_h.Iniciar();
		 mensaje_tb = true;
		
		 
		 
		 try{if (Util.InfoAuditiva) 
		     if (acierto_icono[i])
		 {
		   Util.PlaySound(cont_icono[i]);
		   launcher.play(3);
		   
		 }else{
		 
	   
		 
			 Util.PlaySound("golpe");
			 launcher.stop(); 
          	 
          	 launcher.play(3);
		
		}}catch (Exception e) 
   		{}
		 hilador();
		 
	 }catch (Exception e) 
		{/*Toast.makeText(this, "faLLA SELECCION",
                Toast.LENGTH_SHORT).show();*/}
		
		 
	 }
	
	 public void vibraciones_iconos(String haptico)
	 {
		 
		 try{
	        	launcher = new Launcher(this);
	        	launcher.stop();
	        }catch(RuntimeException re){}
		 
		 
		int codigo_vibra =0 ;
		String sonido = "";
		
		 
		 if (haptico == "internet"  )
			 {codigo_vibra = 0;	
		/*	 ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
	       	 dibujo.setImageResource(R.drawable.def_haptic_icon_y);*/
			 
			}
		 
		 if (haptico == "facebook")
		 { codigo_vibra = 3;
	/*	 ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
       	 dibujo.setImageResource(R.drawable.def_haptic_icon_y);*/
		   }
		     
		 if (haptico== "twitter")
		 { codigo_vibra = 24;
	/*	 ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
       	 dibujo.setImageResource(R.drawable.def_haptic_icon_y);*/
		
		     }
			 
		 if (haptico == "linkedin")
		 { codigo_vibra = 30;
		/* ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
       	 dibujo.setImageResource(R.drawable.def_haptic_icon_y);*/
		
		     }
		    
			 
		 if (haptico == "email")
		 { codigo_vibra = 51;
		/* ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
       	 dibujo.setImageResource(R.drawable.def_haptic_icon_y);*/
		
		 }
		 if (haptico == "line")
		 { codigo_vibra = 60;
		 /* ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
       	 dibujo.setImageResource(R.drawable.def_haptic_icon_y);*/
		}
		 if (haptico == "phone")
		 { codigo_vibra = 61;   // duda
		/* ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
       	 dibujo.setImageResource(R.drawable.def_haptic_icon_y);}*/
		 }
		 if (haptico == "sms"){
			 codigo_vibra = 12;
			/* ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
	       	 dibujo.setImageResource(R.drawable.def_haptic_icon_y);*/
	       	 
	       	 }
		 if (haptico == "store")
			 codigo_vibra = 57;  //duda
		 if (haptico == "talk")
			 codigo_vibra = 36;
		 if (haptico == "googleplus")
			 codigo_vibra = 21;
		 if (haptico == "wasapp")
			 codigo_vibra = 42;
		 if (haptico == "calendario")
			 codigo_vibra = 57;
		 if (haptico == "camara")
			 codigo_vibra = 62;
		 if (haptico == "reloj")
			 codigo_vibra = 15;
		 if (haptico == "calculadora")
			 codigo_vibra = 20;
		
		
		 
			 
			 try{launcher.stop(); 
          	  /*mediaplayer.start();*/
			 
			    if (Util.DiferIconosHapt){
          	    launcher.play(codigo_vibra);
			    }else {launcher.play(3);}
	   	}catch (Exception e) 
   		{/*Toast.makeText(this, "faLLA VIBRACION",
                Toast.LENGTH_SHORT).show();*/}
			
	 }
	 
	 
	 public void mensaje_pantalla( String texto){
	  		
		/* if (Util.MostrarMensajes)*/
		 {
	   	  /*Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();*/
		 }  
			  
	 		
	 	}
	
	public void hilador(){
		  
		 Thread cronometro = new Thread(){
		        public void run(){
		                try{
		                        while(Util.Cr_h.Update()/1000 < 5){
		                        Thread.sleep(50);
		                        }
		                        
		                        if (estado_tb ==1 && mensaje_tb)
		                        {
		                        	handler.post(proceso);
		                        	/*Util.Cr.Iniciar();*/
		             				mensaje_tb = false;
		                        }
		                }
		                catch(Exception e){
		                       /* Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		                        b.show();*/
		                }
		        }
		    };
		   cronometro.start(); }
	 
	 Handler handler = new Handler();
	   
	    Runnable proceso = new Runnable(){
	                public void run() {
	                        try{   if (activar_respuesta)
	                               Util.PlaySound("pulsar");
	                           }
	                        catch(Exception e){                    
	                              /*  Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
	                            b.show();*/     }
	                }};
	                
	                public void adpulsacioncontinua(){
		          		  
		           		 Thread cronometro = new Thread(){
		           		        public void run(){
		           		                try{
		           		                        while(Util.Cr.Update()/100 < 5){
		           		                        Thread.sleep(50);
		           		                        }
		           		                        
		           		                        if (estado_tb == 4 )
		           		                        {
		           		                        	handler_ad.post(proceso_ad);
		           		                        	/*Util.Cr.Iniciar();*/
		           		             				mensaje_tb = false;
		           		                        }
		           		                }
		           		                catch(Exception e){
		           		                       /* Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		           		                        b.show();*/
		           		                }
		           		        }
		           		    };
		           		   cronometro.start(); }
		           	 
		           	 Handler handler_ad = new Handler();
		           	   
		           	    Runnable proceso_ad = new Runnable(){
		           	                public void run() {
		           	                        try{
		           	                              if (activar_respuesta)
		           	                               Util.PlaySound("pulsacion_continua");
		           	                               estado_tb =1;
		           	                              
		           	                           }
		           	                        catch(Exception e){                    
		           	                               /* Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		           	                            b.show();   */ }
		           	                }};

	                public void temporizador(){
		          		  
		           		 Thread cronometro = new Thread(){
		           		        public void run(){
		           		                try{    Util.Cr_p.Iniciar();
		           		                        while(fase_activa){
		           		                          Thread.sleep(500);
		           		                      
		           		                        	handler_tiempo.post(proceso_tiempo);
		           		                        	
		           		                        }
		           		                }
		           		                catch(Exception e){
		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		           		                        b.show();
		           		                }
		           		        }
		           		    };
		           		   cronometro.start(); }
		           	 
		           	 Handler handler_tiempo = new Handler();
		           	   
		           	    Runnable proceso_tiempo = new Runnable(){
		           	                public void run() {
		           	                        try{ 
		           	                        	TextView tiempo =  (TextView) findViewById(R.id.textView2);
		           	                            Thread.sleep(50);
		           	                        	  Util.Cr_p.Update();
		           	                              tiempo.setText(Util.Cr_p.GetStr());
		           	                        	  
		           	                           }
		           	                        catch(Exception e){                    
		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		           	                            b.show();     }
		           	                }};

		                
		          public void nueva_seleccion(){
		   		          		  
		    		           		 Thread cronometro = new Thread(){
		    		           		        public void run(){
		    		           		                try{   
		    		           		                	
		    		           		                	
		    		           		                          while(Util.Cr_ns.Update()/1000 < 3.5){
		    		     		                                  Thread.sleep(50);
		    		     		                              }
		    		           		                      
		    		           		                        	handler_seleccion.post(proceso_seleccion);
		    		           		                        	
		    		           		    			
		    		           		                }
		    		           		                catch(Exception e){
		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		           		                        b.show();
		    		           		                }
		    		           		        }
		    		           		    };
		    		           		   cronometro.start(); }
		    		           	 
		    		           	 Handler handler_seleccion = new Handler();
		    		           	   
		    		           	    Runnable proceso_seleccion = new Runnable(){
		    		           	                public void run() {
		    		           	                        try{ if(fase_activa)
		    		           		    		      {
		    		           	                        Util.Cr_i.Iniciar();
		    		           	                        		
		    		           	                     	mensaje_texto = "NUEVA SELECCION";
				    		           	 	    	  	mensaje_pantalla();
		    		           	                      
		    		           	 	    		        Util.PlaySound("nueva_seleccion");
		    		           	                        memorizar_icono();
		    		           	                        
		    		           	 	    	  	    /*	Util.Cr_i.Iniciar();
		    		           	 	    	  	        while(Util.Cr_i.Update()/1000 < 2){
		     		                                    Thread.sleep(50);
		     		                                      }
		    		           	 	    	  	       
		    		           	 	    	  	    	
		    		           	 	    	 	        memoria_icono = requerimiento_aleatorio();  
		    		           	 	    	 	        Util.Log("   Seleccion icono: " + memoria_icono + " (" + Util.Cr_p.GetStr() + ")" );
		    		           	 		                Util.Log_Excel("Seleccion: " + memoria_icono + ";" + Util.Cr_p.GetStr() +";" );
		    		           	 		                Util.Log_Excel_nl();*/
		    		           	 		                
		    		           	 		               
		    		           	                        
		    		           	 	    	 	        
		    		           	 	    	 	        
		    		           	 	    		      }
		    		           	                        	
				    		           		                	}
		    		           	                        catch(Exception e){                    
		    		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		           	                            b.show();     }
		    		           	                }};

		    		                

		    		           	             public void mostrar_figura(){   // no mostrar 
		    			   		          		  
		    		    		           		 Thread cronometro = new Thread(){
		    		    		           		        public void run(){
		    		    		           		                try{   
		    		    		           		                	
		    		    		           		                	
		    		    		           		                          while(Util.Cr.Update()/1000 < 1.5){
		    		    		     		                                  Thread.sleep(50);
		    		    		     		                              }
		    		    		           		                      
		    		    		           		                        	handler_figura.post(proceso_figura);
		    		    		           		                        	
		    		    		           		    			
		    		    		           		                }
		    		    		           		                catch(Exception e){
		    		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		           		                        b.show();
		    		    		           		                }
		    		    		           		        }
		    		    		           		    };
		    		    		           		   cronometro.start(); }
		    		    		           	 
		    		    		           	 Handler handler_figura = new Handler();
		    		    		           	   
		    		    		           	    Runnable proceso_figura = new Runnable(){
		    		    		           	                public void run() {
		    		    		           	                        try{ 
		    		    		           	                        	
		    		    		           	                        	
		    		    		           	                        	if (correcto){
		    				    		           		                	int i =0;
		    				    		           		                  while (i<16)
		    				    		           		    			 {
		    				    		           		    				 if (cont_icono[i]== memoria_icono){
		    				    		           		    				    acierto_icono[i] = true;
		    				    		           		    				    visible_icono(i,imagen(cont_icono[i]));
		    				    		           		    				 }
		    				    		           		    				 i++;
		    				    		           		    			 }}else{
		    		    		           	                        	
		    				    		           		    			if (!error_icono[indice_icono]){	 
		    		    		           	                        	visible_icono(indice_icono,imagen ("def_int"));
		    		    		           	                        } else{ visible_icono(indice_icono,imagen ("def_error")); }
		    		    		           	                           }}
		    		    		           	                        catch(Exception e){                    
		    		    		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		           	                            b.show();     }
		    		    		           	                }};

		    		    		                
		    		    		           	             public void nombrar(){
		   		    			   		          		  
		    		    		    		           		 Thread cronometro = new Thread(){
		    		    		    		           		        public void run(){
		    		    		    		           		                try{   
		    		    		    		           		                	
		    		    		    		           		                	
		    		    		    		           		                          while(Util.Cr.Update()/1000 < 0.1){
		    		    		    		     		                                  Thread.sleep(50);
		    		    		    		     		                              }
		    		    		    		           		                      
		    		    		    		           		                        	handler_nombrar.post(proceso_nombrar);
		    		    		    		           		                        	
		    		    		    		           		    			
		    		    		    		           		                }
		    		    		    		           		                catch(Exception e){
		    		    		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		           		                        b.show();
		    		    		    		           		                }
		    		    		    		           		        }
		    		    		    		           		    };
		    		    		    		           		   cronometro.start(); }
		    		    		    		           	 
		    		    		    		           	 Handler handler_nombrar = new Handler();
		    		    		    		           	   
		    		    		    		           	    Runnable proceso_nombrar = new Runnable(){
		    		    		    		           	                public void run() {
		    		    		    		           	                        try{ 
		    		    		    		           	                        	if (Util.InfoAuditiva)
		    		    		    		           	                        	Util.PlaySound(cont_icono[indice_icono]);
		    		    		    		           	                        	
		    		    		    		           	                        	}
		    		    		    		           	                        catch(Exception e){                    
		    		    		    		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		           	                            b.show();     }
		    		    		    		           	                }};
		    		    		    		           	             public void incorrecto(){
		    			   		    			   		          		  
		    		    		    		    		           		 Thread cronometro = new Thread(){
		    		    		    		    		           		        public void run(){
		    		    		    		    		           		                try{   
		    		    		    		    		           		                	
		    		    		    		    		           		                	
		    		    		    		    		           		                          while(Util.Cr_ns.Update()/1000 < 0.3){
		    		    		    		    		     		                                  Thread.sleep(50);
		    		    		    		    		     		                              }
		    		    		    		    		           		                      
		    		    		    		    		           		                        	handler_incorrecto.post(proceso_incorrecto);
		    		    		    		    		           		                        	
		    		    		    		    		           		    			
		    		    		    		    		           		                }
		    		    		    		    		           		                catch(Exception e){
		    		    		    		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		           		                        b.show();
		    		    		    		    		           		                }
		    		    		    		    		           		        }
		    		    		    		    		           		    };
		    		    		    		    		           		   cronometro.start(); }
		    		    		    		    		           	 
		    		    		    		    		           	 Handler handler_incorrecto = new Handler();
		    		    		    		    		           	   
		    		    		    		    		           	    Runnable proceso_incorrecto = new Runnable(){
		    		    		    		    		           	                public void run() {
		    		    		    		    		           	                        try{ 
		    		    		    		    		           	                        	Util.PlaySound("incorrecto");
		    		    		    		    		           	                        	
		    		    		    		    		           	                        	}
		    		    		    		    		           	                        catch(Exception e){                    
		    		    		    		    		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		           	                            b.show();     }
		    		    		    		    		           	                }};
		    		    		    		    		           	                
		    		    		    		    		           	             public void mensaje_pantalla(){
		   		    			   		    			   		          		  
		    		    		    		    		    		           		 Thread cronometro = new Thread(){
		    		    		    		    		    		           		        public void run(){
		    		    		    		    		    		           		                try{   
		    		    		    		    		    		           		                	
		    		    		    		    		    		           		                	
		    		    		    		    		    		           		                           while(Util.Cr_i.Update()/100 < 0.1){
		    		    		    		    		    		     		                                  Thread.sleep(50);
		    		    		    		    		    		     		                              }
		    		    		    		    		    		           		                      
		    		    		    		    		    		           		                        	handler_mensajes.post(proceso_mensajes);
		    		    		    		    		    		           		                        	
		    		    		    		    		    		           		    			
		    		    		    		    		    		           		                }
		    		    		    		    		    		           		                catch(Exception e){
		    		    		    		    		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		           		                        b.show();
		    		    		    		    		    		           		                }
		    		    		    		    		    		           		        }
		    		    		    		    		    		           		    };
		    		    		    		    		    		           		   cronometro.start(); }
		    		    		    		    		    		           	 
		    		    		    		    		    		           	 Handler handler_mensajes = new Handler();
		    		    		    		    		    		           	   
		    		    		    		    		    		           	    Runnable proceso_mensajes = new Runnable(){
		    		    		    		    		    		           	                public void run() {
		    		    		    		    		    		           	                        try{ 
		    		    		    		    		    		           	                        	if (Util.MostrarMensajes){
		    		    		    		    		    		           	                        	Toast b=Toast.makeText(getApplicationContext(), mensaje_texto,100);
		    		    		    		    		    		           		                        b.show();
		    		    		    		    		    		           	                        	}
		    		    		    		    		    		           	                        	
		    		    		    		    		    		           	                        	
		    		    		    		    		    		           	                        	}
		    		    		    		    		    		           	                        catch(Exception e){                    
		    		    		    		    		    		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		           	                            b.show();     }
		    		    		    		    		    		           	                }};

		    		    		    		    		    		           	             public void memorizar_icono(){
		    			   		    			   		    			   		          		  
		    		    		    		    		    		    		           		 Thread cronometro = new Thread(){
		    		    		    		    		    		    		           		        public void run(){
		    		    		    		    		    		    		           		                try{   
		    		    		    		    		    		    		           		                	
		    		    		    		    		    		    		           		                	
		    		    		    		    		    		    		           		                           while(Util.Cr_i.Update()/1000 < 3){
		    		    		    		    		    		    		     		                                  Thread.sleep(50);
		    		    		    		    		    		    		     		                              }
		    		    		    		    		    		    		           		                      
		    		    		    		    		    		    		           		                        	handler_icono.post(proceso_icono);
		    		    		    		    		    		    		           		                        	
		    		    		    		    		    		    		           		    			
		    		    		    		    		    		    		           		                }
		    		    		    		    		    		    		           		                catch(Exception e){
		    		    		    		    		    		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		    		           		                        b.show();
		    		    		    		    		    		    		           		                }
		    		    		    		    		    		    		           		        }
		    		    		    		    		    		    		           		    };
		    		    		    		    		    		    		           		   cronometro.start(); }
		    		    		    		    		    		    		           	 
		    		    		    		    		    		    		           	 Handler handler_icono = new Handler();
		    		    		    		    		    		    		           	   
		    		    		    		    		    		    		           	    Runnable proceso_icono = new Runnable(){
		    		    		    		    		    		    		           	                public void run() {
		    		    		    		    		    		    		           	                        try{ 
		    		    		    		    		    		    		           	                        	
		    		    		    		    		    		    		           	                         memoria_icono = requerimiento_aleatorio();
		    		    		    		    		    		    		           	      			    
		    		    		    		    		    		    		           	      		    	   
		    		    		    		    		    		    		           	      			    
		    		    		    		    		    		    		           	      			        Util.Log("   Seleccion icono: " + memoria_icono + " (" + Util.Cr_p.GetStr() + ")" );
		    		    		    		    		    		    		           	      			        Util.Log_Excel_nl();
		    		    		    		    		    		    		           	                        Util.Log_Excel("Selecci�n: " + memoria_icono + ";" + Util.Cr_p.GetStr() +";" );
		    		    		    		    		    		    		           	                        Util.Log_Excel_nl();
		    		    		    		    		    		    		           	                        	
		    		    		    		    		    		    		           	                        	
		    		    		    		    		    		    		           	                        	}
		    		    		    		    		    		    		           	                        catch(Exception e){                    
		    		    		    		    		    		    		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		    		           	                            b.show();     }
		    		    		    		    		    		    		           	                }};
		    		    		    		    		    		    		           	                
		    		    		    		    		    		    		           	             public void activar_resp(){
		   		    			   		    			   		    			   		          		  
		    		    		    		    		    		    		    		           		 Thread cronometro = new Thread(){
		    		    		    		    		    		    		    		           		        public void run(){
		    		    		    		    		    		    		    		           		                try{   
		    		    		    		    		    		    		    		           		                	
		    		    		    		    		    		    		    		           		                	
		    		    		    		    		    		    		    		           		                           while(Util.Cr_act.Update()/1000 < 1){
		    		    		    		    		    		    		    		     		                                  Thread.sleep(50);
		    		    		    		    		    		    		    		     		                              }
		    		    		    		    		    		    		    		           		                      
		    		    		    		    		    		    		    		           		                        	handler_activar.post(proceso_activar);
		    		    		    		    		    		    		    		           		                        	
		    		    		    		    		    		    		    		           		    			
		    		    		    		    		    		    		    		           		                }
		    		    		    		    		    		    		    		           		                catch(Exception e){
		    		    		    		    		    		    		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		    		    		           		                        b.show();
		    		    		    		    		    		    		    		           		                }
		    		    		    		    		    		    		    		           		        }
		    		    		    		    		    		    		    		           		    };
		    		    		    		    		    		    		    		           		   cronometro.start(); }
		    		    		    		    		    		    		    		           	 
		    		    		    		    		    		    		    		           	 Handler handler_activar = new Handler();
		    		    		    		    		    		    		    		           	   
		    		    		    		    		    		    		    		           	    Runnable proceso_activar = new Runnable(){
		    		    		    		    		    		    		    		           	                public void run() {
		    		    		    		    		    		    		    		           	                        try{ 
		    		    		    		    		    		    		    		           	                        	
		    		    		    		    		    		    		    		           	                           activar_respuesta = true;
		    		    		    		    		    		    		    		           	                        	}
		    		    		    		    		    		    		    		           	                        catch(Exception e){                    
		    		    		    		    		    		    		    		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		    		    		           	                            b.show();     }
		    		    		    		    		    		    		    		           	                }};
		    		    		    		    		    		    		    		           	                
		    		    		    		    		    		    		    		           	                
		    		    		    		    		    		    		    		           	             public void final_test(){
		    			   		    			   		    			   		    			   		          		  
		    		    		    		    		    		    		    		    		           		 Thread cronometro = new Thread(){
		    		    		    		    		    		    		    		    		           		        public void run(){
		    		    		    		    		    		    		    		    		           		                try{   
		    		    		    		    		    		    		    		    		           		                	
		    		    		    		    		    		    		    		    		           		                	
		    		    		    		    		    		    		    		    		           		                           while(Util.Cr_ns.Update()/1000 < 2){
		    		    		    		    		    		    		    		    		     		                                  Thread.sleep(50);
		    		    		    		    		    		    		    		    		     		                              }
		    		    		    		    		    		    		    		    		           		                      
		    		    		    		    		    		    		    		    		           		                        	handler_ftest.post(proceso_ftest);
		    		    		    		    		    		    		    		    		           		                        	
		    		    		    		    		    		    		    		    		           		    			
		    		    		    		    		    		    		    		    		           		                }
		    		    		    		    		    		    		    		    		           		                catch(Exception e){
		    		    		    		    		    		    		    		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		    		    		    		           		                        b.show();
		    		    		    		    		    		    		    		    		           		                }
		    		    		    		    		    		    		    		    		           		        }
		    		    		    		    		    		    		    		    		           		    };
		    		    		    		    		    		    		    		    		           		   cronometro.start(); }
		    		    		    		    		    		    		    		    		           	 
		    		    		    		    		    		    		    		    		           	 Handler handler_ftest = new Handler();
		    		    		    		    		    		    		    		    		           	   
		    		    		    		    		    		    		    		    		           	    Runnable proceso_ftest = new Runnable(){
		    		    		    		    		    		    		    		    		           	                public void run() {
		    		    		    		    		    		    		    		    		           	                        try{ 
		    		    		    		    		    		    		    		    		           	                        	
		    		    		    		    		    		    		    		    		           	                        	Util.PlaySound("fase_terminada");
		    		    		    		    		    		    		    		    		           	      	    			 fase_activa = false;
		    		    		    		    		    		    		    		    		           	      	    			 Util.Log("FINAL TEST" );
		    		    		    		    		    		    		    		    		           	      	    			Util.Log_Excel_nl(); 	  
		    		    		    		    		    		    		    		    		           	    	        		  	Util.Log_Excel("FINAL TEST" );
		    		    		    		    		    		    		    		    		           	    	        		  	Util.Log_Excel_nl(); 
		    		    		    		    		    		    		    		    		           	    	        		  	mensaje_pantalla("TEST TERMINADO");
		    		    		    		    		    		    		    		    		           	    	        		  	
		    		    		    		    		    		    		    		    		           	                        	}
		    		    		    		    		    		    		    		    		           	                        catch(Exception e){                    
		    		    		    		    		    		    		    		    		           	                                Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		    		    		    		           	                            b.show();     }
		    		    		    		    		    		    		    		    		           	                }};
		    		    		    		    		    		    		    		    		           	                
		    		    		    		    		    		    		    		    		           	             public void comienzo_test(){
		   		    			   		    			   		    			   		    			   		          		  
		    		    		    		    		    		    		    		    		    		           		 Thread cronometro = new Thread(){
		    		    		    		    		    		    		    		    		    		           		        public void run(){
		    		    		    		    		    		    		    		    		    		           		                try{   
		    		    		    		    		    		    		    		    		    		           		                	
		    		    		    		    		    		    		    		    		    		           		                	
		    		    		    		    		    		    		    		    		    		           		                           while(Util.Cr_inicio.Update()/1000 < 0.8){
		    		    		    		    		    		    		    		    		    		     		                                  Thread.sleep(50);
		    		    		    		    		    		    		    		    		    		     		                              }
		    		    		    		    		    		    		    		    		    		           		                      
		    		    		    		    		    		    		    		    		    		           		                        	handler_iniciotest.post(proceso_iniciotest);
		    		    		    		    		    		    		    		    		    		           		                        	
		    		    		    		    		    		    		    		    		    		           		    			
		    		    		    		    		    		    		    		    		    		           		                }
		    		    		    		    		    		    		    		    		    		           		                catch(Exception e){
		    		    		    		    		    		    		    		    		    		           		                        Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		    		    		    		    		           		                        b.show();
		    		    		    		    		    		    		    		    		    		           		                }
		    		    		    		    		    		    		    		    		    		           		        }
		    		    		    		    		    		    		    		    		    		           		    };
		    		    		    		    		    		    		    		    		    		           		   cronometro.start(); }
		    		    		    		    		    		    		    		    		    		           	 
		    		    		    		    		    		    		    		    		    		           	 Handler handler_iniciotest = new Handler();
		    		    		    		    		    		    		    		    		    		           	   
		    		    		    		    		    		    		    		    		    		           	    Runnable proceso_iniciotest = new Runnable(){
		    		    		    		    		    		    		    		    		    		           	                public void run() {
		    		    		    		    		    		    		    		    		    		           	                        try{ 
		    		    		    		    		    		    		    		    		    		           	                        	
		    		    		    		    		    		    		    		    		    		           	                        	Util.PlaySound("comienzo_test1");
		    		    		    		    		    		    		    		    		    		           	      	    			 
		    		    		    		    		    		     	
		    		    		    		    		    		    		    		    		    		           	                        	}
		    		    		    		    		    		    		    		    		    		           	                        catch(Exception e){                    
		    		    		    		    		    		    		    		    		    		           	                               /* Toast b=Toast.makeText(getApplicationContext(), e.toString(), 2000);
		    		    		    		    		    		    		    		    		    		           	                            b.show(); */    }
		    		    		    		    		    		    		    		    		    		           	                }};
		    		    		    		    		    		    		    		    		    		           	                
		    		    		    		    		           	                
}

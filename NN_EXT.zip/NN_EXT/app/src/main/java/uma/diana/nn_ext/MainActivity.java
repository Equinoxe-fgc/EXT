package uma.diana.nn_ext;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.Toast;

import com.immersion.uhl.Launcher;

public class MainActivity extends Activity {

	
	public boolean entrada[]= new boolean [20]; // Coordinadores de selecci�n de posiciones de iconos
	public String cont_icono[] = new String [20]; //contenido icono
	public String cont_icono_y[] = new String [20];
	
	  
	
	
/*	 public boolean entrada_calculadora= true; 
	 public boolean entrada_internet = true; 
	 public boolean entrada_facebook =true;
	 public boolean entrada_twitter = true;
	 public boolean entrada_linkedin = true;
	 public boolean entrada_email = true;
	 public boolean entrada_line = true;
	 public boolean entrada_phone =true;
	 public boolean entrada_wasapp = true;
	 public boolean entrada_sms = true;
	 public boolean entrada_store = true;
	 public boolean entrada_talk = true;
	 public boolean entrada_googleplus = true;
	 public boolean entrada_calendario = true;
	 public boolean entrada_camara = true;
	 public boolean entrada_reloj = true; */
	 
	
	 
	 private  Launcher launcher;
	 
	 public int estado_tb = 0;
	
	 public void  visible_icono( int indice, int img){  // indice de icono, contenido de icono
			try{ 
			  if (indice == 0){
			   ImageView dibujo =  (ImageView) findViewById(R.id.imageView1);
		       dibujo.setImageResource(img);
		       dibujo.refreshDrawableState();}
			  if (indice == 1){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView2);
			       dibujo.setImageResource(img);
			       dibujo.refreshDrawableState();}
			  if (indice == 2){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView3);
			       dibujo.setImageResource(img);
			       dibujo.refreshDrawableState();}
			  if (indice == 3){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView4);
			       dibujo.setImageResource(img);
			       dibujo.refreshDrawableState();}
			  if (indice == 4){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView5);
			       dibujo.setImageResource(img);
			       dibujo.refreshDrawableState();}
			  if (indice == 5){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView6);
			       dibujo.setImageResource(img);
			       dibujo.refreshDrawableState();}
			  if (indice == 6){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView7);
			       dibujo.setImageResource(img);
			       dibujo.refreshDrawableState();}
			  if (indice == 7){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView8);
			       dibujo.setImageResource(img);
			       dibujo.refreshDrawableState();}
			
			  if (indice == 8){
				   ImageView dibujo =  (ImageView) findViewById(R.id.imageView9);
			       dibujo.setImageResource(img);
			       dibujo.refreshDrawableState();}			
				  if (indice == 9){
					   ImageView dibujo =  (ImageView) findViewById(R.id.imageView10);
				       dibujo.setImageResource(img);
				       dibujo.refreshDrawableState();}
				  if (indice == 10){
					   ImageView dibujo =  (ImageView) findViewById(R.id.imageView11);
				       dibujo.setImageResource(img);
				       dibujo.refreshDrawableState();}
				  if (indice == 11){
					   ImageView dibujo =  (ImageView) findViewById(R.id.imageView12);
				       dibujo.setImageResource(img);
				       dibujo.refreshDrawableState();}
				  if (indice == 12){
					   ImageView dibujo =  (ImageView) findViewById(R.id.imageView13);
				       dibujo.setImageResource(img);
				       dibujo.refreshDrawableState();}
				  if (indice == 13){
					   ImageView dibujo =  (ImageView) findViewById(R.id.imageView14);
				       dibujo.setImageResource(img);
				       dibujo.refreshDrawableState();}
				  if (indice == 14){
					   ImageView dibujo =  (ImageView) findViewById(R.id.imageView15);
				       dibujo.setImageResource(img);
				       dibujo.refreshDrawableState();}
				  if (indice == 15){
					   ImageView dibujo =  (ImageView) findViewById(R.id.imageView16);
				       dibujo.setImageResource(img);
				       dibujo.refreshDrawableState();}
				
				      
	        }catch (Exception e) 
	        	{/*Toast.makeText(this, "falla  VISIBLE_ICONO",
	                    Toast.LENGTH_SHORT).show();*/}
		
		
		
		
		}
		
	    
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
      
       /* Toast.makeText(MainActivity.this, "Alarma detenida", Toast.LENGTH_LONG).show();*/
        
        Util.AM = getAssets();
        
        /*texto.setText("SELECCI�N DE POSICI�N");*/
        loadfase();
        
        int i;
        i=0;
        while( i < 16){
        	
        	  visible_icono(i, imagen(cont_icono[i]));
			  entrada[i]=true; 
			  i++;
			}
   	 
        
       
     
    }
     
    public void loadfase(){
    	
    	
    	if (Util.DiferIconosHapt)
        
        {	
        cont_icono[0]="internet";
        cont_icono[1]="facebook";
        cont_icono[2]= "twitter";
        cont_icono[3]="linkedin";
        cont_icono[4]="email";
        cont_icono[5]="line";
        cont_icono[6]="phone";
        cont_icono[7]="sms";
        cont_icono[8]="store";
        cont_icono[9]="talk";
        cont_icono[10]="googleplus";
        cont_icono[11]="wasapp";
        cont_icono[12]="calendario";
        cont_icono[13]="camara";
        cont_icono[14]="reloj";
        cont_icono[15]="calculadora";
        
        cont_icono_y[0]= "internet_y";
        cont_icono_y[1]="facebook_y";
        cont_icono_y[2]= "twitter_y";
        cont_icono_y[3]="linkedin_y";
        cont_icono_y[4]="email_y";
        cont_icono_y[5]="line_y";
        cont_icono_y[6]="phone_y";
        cont_icono_y[7]="sms_y";
        cont_icono_y[8]="store_y";
        cont_icono_y[9]="talk_y";
        cont_icono_y[10]="googleplus_y";
        cont_icono_y[11]="wasapp_y";
        cont_icono_y[12]="calendario_y";
        cont_icono_y[13]="camara_y";
        cont_icono_y[14]="reloj_y";
        cont_icono_y[15]="calculadora_y";
        
        
        
      /* Toast notification =	Toast.makeText(this, "ATENCI�N: MODO DE VIBRACIONES DIFERENCIADAS. PULSE PARA COMENZAR ENTRENAMIENTO", Toast.LENGTH_SHORT);
       notification.setGravity(Gravity.TOP, 0, 20); 
       notification.show();*/
        
        Util.PlaySound("v_dif");
        
        }else{
        	cont_icono[0]="internet";
            cont_icono[5]="facebook";
            cont_icono[10]= "twitter";
            cont_icono[9]="linkedin";
            cont_icono[6]="email";
            cont_icono[2]="line";
            cont_icono[4]="phone";
            cont_icono[11]="sms";
            cont_icono[8]="store";
            cont_icono[3]="talk";
            cont_icono[1]="googleplus";
            cont_icono[7]="wasapp";
            cont_icono[14]="calendario";
            cont_icono[13]="camara";
            cont_icono[12]="reloj";
            cont_icono[15]="calculadora";
            
            cont_icono_y[0]= "internet_y";
            cont_icono_y[5]="facebook_y";
            cont_icono_y[10]= "twitter_y";
            cont_icono_y[9]="linkedin_y";
            cont_icono_y[6]="email_y";
            cont_icono_y[2]="line_y";
            cont_icono_y[4]="phone_y";
            cont_icono_y[11]="sms_y";
            cont_icono_y[8]="store_y";
            cont_icono_y[3]="talk_y";
            cont_icono_y[1]="googleplus_y";
            cont_icono_y[7]="wasapp_y";
            cont_icono_y[14]="calendario_y";
            cont_icono_y[13]="camara_y";
            cont_icono_y[12]="reloj_y";
            cont_icono_y[15]="calculadora_y";
        	
     
            /*Toast notification =	Toast.makeText(this, "ATENCI�N: MODO DE VIBRACIONES IGUALES. PULSE PARA COMENZAR ENTRENAMIENTO", Toast.LENGTH_LONG);
            notification.setGravity(Gravity.TOP, 0, 0); 
            notification.show();*/
            Util.PlaySound("v_ig");
             
       	 
        }
        
    
        
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
   
    public int imagen ( String img){
		int entero=0;
		try{ 
		
		 if (img == "internet")
			 entero= R.drawable.internet;
		 if (img == "internet_y")
			 entero= R.drawable.internet_y;
 	     if (img == "facebook")
			entero= R.drawable.facebook;
 	     if (img== "facebook_y")
 	    	 entero=R.drawable.facebook_y;
		 if (img=="twitter")
			 entero = R.drawable.twitter;
		 if (img=="twitter_y")
			 entero = R.drawable.twitter_y;
		 
		 if (img=="linkedin")
			 entero =R.drawable.linkedin;
		 if (img=="linkedin_y")
			 entero =R.drawable.linkedin_y;
		 if (img=="wasapp")
			 entero =R.drawable.wasapp;
		 if (img=="wasapp_y")
			 entero =R.drawable.wasapp_y;
		 if (img=="phone")
			 entero =R.drawable.phone;
		 if (img=="phone_y")
			 entero =R.drawable.phone_y;
		 if (img=="sms")
			 entero =R.drawable.esemese;
		 if (img=="sms_y")
			 entero =R.drawable.esemese_y;
		 if (img=="email")
			 entero = R.drawable.email;
		 if (img=="email_y")
			 entero = R.drawable.email_y;
		 if (img=="line")
			 entero =R.drawable.line;
		 if (img=="line_y")
			 entero =R.drawable.line_y;
		 if (img=="googleplus_y")
			 entero = R.drawable.googleplus_y;
		 if (img=="googleplus")
			 entero = R.drawable.googleplus;
		 if (img=="store")
			 entero= R.drawable.store;
		 if (img=="store_y")
			 entero= R.drawable.store_y;
		 if (img=="talk")
			 entero= R.drawable.talk;
		 if (img=="talk_y")
			 entero= R.drawable.talk_y;
		 if (img=="calculadora")
			 entero=R.drawable.calculadora;
		 if (img=="calculadora_y")
			 entero=R.drawable.calculadora_y;
		 if (img=="calendario")
			 entero=R.drawable.calendario;
		 if (img=="calendario_y")
			 entero=R.drawable.calendario_y;
		 if (img=="reloj")
			 entero= R.drawable.reloj; 
		 if (img=="reloj_y")
			 entero= R.drawable.reloj_y; 
		 if (img=="camara")
			 entero= R.drawable.camara;
		 if (img=="camara_y")
			 entero= R.drawable.camara_y;
		 if (img=="def")
			 entero= R.drawable.def;
		 if (img == "deficon")
			 entero = R.drawable.deficon;
		 if (img == "def_int")
			 entero = R.drawable.def_int;
		 
		 if (img == "def_int_y")
			 entero = R.drawable.def_int_y;
		 
		 if (img == "def_haptic_icon_disabled")
			 entero = R.drawable.def_haptic_icon_disabled;
		 
		 if (img == "def_haptic_icon_y")
			 entero = R.drawable.def_haptic_icon_y;
		 
		 if (img == "def_error")
			 entero = R.drawable.def_error;
		 
			 
		
		 
		}catch (Exception e) 
    	{/*Toast.makeText(this, "falla  IMAGEN",
                Toast.LENGTH_SHORT).show();*/}
		
		 return entero;
		
	}
	
    
    
    public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		
    	
    	


	/*	TextView salida = (TextView) findViewById(R.id.TextViewSalida);*/
		
		 
/*
		salida.append(evento.toString() );
		try
		  {Thread.sleep(1500);}
		catch (Exception e) 
   		{};
   		
   		salida.clearComposingText(); */
                     
		
    	try{
        	launcher = new Launcher(this);
        }catch(RuntimeException re){}
		
		
		String acciones[] = { "ACTION_DOWN", "ACTION_UP", "ACTION_MOVE", "ACTION_CANCEL","ACTION_OUTSIDE", "ACTION_POINTER_DOWN", "ACTION_POINTER_UP" };

		int accion = event.getAction();

		int codigoAccion = accion & MotionEvent.ACTION_MASK;
		
		String icono;

	/*	salida.append(acciones[codigoAccion]);

		for (int i = 0; i < evento.getPointerCount(); i++) {

		salida.append(" puntero: "  + evento.getPointerId(i) + 
		" x:" + evento.getX(i) + " y:" + evento.getY(i));

		}

		salida.append("\n");*/
		
		
		if(acciones[codigoAccion].equals("ACTION_POINTER_DOWN"))
			
		{
			
			  
	     if (estado_tb==1)
	    	 estado_tb = 2;
	     
	     if (estado_tb ==3)
	    	 estado_tb = 4;
		}
		
       if(acciones[codigoAccion].equals("ACTION_POINTER_UP"))
			
		{
			
    	   if (estado_tb==2)
  	    	 estado_tb = 3;
  	     
  	     if (estado_tb ==4 )
  	     {
  	    	 estado_tb = 5;
  	    	 mensaje_pantalla("ACCION_EJECUTADA");
  	    	 
  	    	 
  	    /*	vibraciones_iconos();
*/  	    	 
  	    	 
  	    	 estado_tb =1;
  	     }
		
		
	
		}
		
		/*salida.clearComposingText();*/
		if(acciones[codigoAccion].equals("ACTION_DOWN"))
			
		{
			
			/*  entrada_calculadora= true; 
			  entrada_internet = true; 
			  entrada_facebook =true;
			  entrada_twitter = true;
			  entrada_linkedin = true;
			  entrada_email = true;
			  entrada_line = true;
			  entrada_phone =true;
			  entrada_wasapp = true;
			  entrada_sms = true;
			  entrada_store = true;
			  entrada_talk = true;
			  entrada_googleplus = true;
			  entrada_calendario = true;
			  entrada_camara = true;
			  entrada_reloj = true;*/
			
			
			int i;
	        i=0;
	        while( i < 16){
	        	
	        	  visible_icono(i, imagen(cont_icono[i]));
				  entrada[i]=true; 
				  i++;
				}
		       
		      
		}
		
		if ((acciones[codigoAccion].equals("ACTION_MOVE") || acciones[codigoAccion].equals("ACTION_DOWN")) && event.getPointerCount() == 1 ){
			
			
			if (estado_tb <1)
			estado_tb = 1;
			
			/*if (icon.Name.equals("internet"))*/
        	if ((event.getX() < 175)  && (event.getY() < 400) && (event.getY() > 200) && entrada[0])
        	/*	if ((pixelX < 200)  && (pixelY < 300) && entrada_internet)*/
        	     {
        		 
        		
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView);
          	     dibujo.setImageResource(imagen(cont_icono_y[0]));
        		  
          	   
        		
        		     icono = cont_icono[0];
        		     vibraciones_iconos(icono);
        	    	 mensaje_pantalla(icono);
        	    	 seleccion_tb(icono);
        	    	 entrada[0] = false;
	 	        	    }
        		
        		
        		 
        	 if    (!((event.getX() < 175)  && (event.getY() < 400) && (event.getY() > 150)) )
        	/*	if(!((pixelX < 200)  && (pixelY < 300)))*/
        	 {
        	 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView);
       	   dibujo.setImageResource(imagen(cont_icono[0]));
        		    	 entrada[0]= true; 
        	 }
        			
          /*  if (icon.Name.equals("facebook"))*/
        	
        	if ((event.getX() > 175)  && (event.getX() <350) && (event.getY() < 400) && (event.getY() > 150)&& entrada[1])
        	/*	if ((pixelX> 200)  && (pixelX <400) && (pixelY< 300) && entrada_facebook)*/
        		
        	     {
        		
        		 ImageView dibujo =  (ImageView) findViewById(R.id.imageView0);
          	     dibujo.setImageResource(imagen(cont_icono_y[1]));
        		   
          	      
        		 
        	    	 icono = cont_icono[1];
        	    	 vibraciones_iconos(icono);
        	    	 mensaje_pantalla(icono);
        	    	 seleccion_tb(icono);
        	    	 entrada[1]= false;
	 	        	    }
        	
        	 if    (!((event.getX() > 175)  && (event.getX() <350) && (event.getY() < 400)&& (event.getY() > 150)) )
        	/*	if (!((pixelX> 200)  && (pixelX <400) && (pixelY< 300)))*/
        	 {ImageView dibujo =  (ImageView) findViewById(R.id.imageView0);
        	   dibujo.setImageResource(imagen(cont_icono[1]));
		    	 entrada[1] = true; }
        	 
        	 
       	/* if (icon.Name.equals("twitter")) */
        	if ((event.getX() > 350)  && (event.getX() <525) && (event.getY() < 400) && (event.getY() > 150) && entrada[2])
       /* 	if ((pixelX > 400)  && (pixelX <600) && (pixelY< 300) && entrada_twitter)*/
    	     {
        		
        		ImageView dibujo =  (ImageView) findViewById(R.id.ImageView02);
           	   dibujo.setImageResource(imagen(cont_icono_y[2]));
        		
        		 
    	    	 icono =cont_icono[2];
    	    	  vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[2]= false;
        	 
    	     }
        	
        	if    (!((event.getX() > 350)  && (event.getX() <525) && (event.getY() < 400)&& (event.getY() > 150)) )
        	/*	 if (!((pixelX > 400)  && (pixelX <600) && (pixelY< 300)))*/
        	{   ImageView dibujo =  (ImageView) findViewById(R.id.ImageView02);
            	   dibujo.setImageResource(imagen(cont_icono[2]));
		    	 entrada[2]= true; }
        	
        	 
    	    	 
      /*  if (icon.Name.equals("linkedin")) */
        	 if ((event.getX() > 525)  && (event.getX() <700) && (event.getY() < 400)&& (event.getY() > 150) && entrada[3])
		    		
        	 {
        		 
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView03);
            	   dibujo.setImageResource(imagen(cont_icono_y[3]));
        		  
        		
    	    	 icono = cont_icono[3];
    	    	  vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[3]= false;
    	    	 
 	        	    }  	     
        		
        	 if    (!((event.getX() > 525)  && (event.getX() <700) && (event.getY() < 400)&& (event.getY() > 150)) )
        	 {
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView03);
            	   dibujo.setImageResource(imagen(cont_icono[3]));
        		 entrada[3] = true; }
        	 
        	 /*if (icon.Name.equals("email"))*/
        	 if ((event.getX() > 0)  && (event.getX() <175) && (event.getY() > 400 ) && (event.getY() < 700)  && entrada[4])
				  
    	     {
        		
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView04);
            	 dibujo.setImageResource(imagen(cont_icono_y[4]));
        		
        		 
        		
    	    	 icono = cont_icono[4];
    	    	  vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[4] = false;
    	    
 	        	    }
        	 
        	 if    (!((event.getX() > 0)  && (event.getX() <175) && (event.getY() > 400 ) && (event.getY() < 700) ) )
        	 { ImageView dibujo =  (ImageView) findViewById(R.id.ImageView04);
        	   dibujo.setImageResource(imagen(cont_icono[4]));
        		 entrada[4] = true; }
        	 
        	/* if (icon.Name.equals("line"))*/
        	 if ((event.getX() > 175)  && (event.getX() <350) && (event.getY() > 400 ) && (event.getY() < 700)  && entrada[5])
				  
    	     {
        		 
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView05);
          	   dibujo.setImageResource(imagen(cont_icono_y[5]));
        		 
    	    	 
        		
    	    	 icono = cont_icono[5];
    	    	 vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[5] = false;
    	    
 	        	    }
        	 
        	 
        	 if    (!((event.getX() > 175)  && (event.getX() <350) && (event.getY() > 400 ) && (event.getY() < 700))) 
        	 {	 entrada[5] = true; 
        	 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView05);
      	      dibujo.setImageResource(imagen(cont_icono[5]));}
        	 
        	 
        	 /* if (icon.Name.equals("phone"))*/
        	 if ((event.getX() > 350)  && (event.getX() <525) && (event.getY() > 400 ) && (event.getY() < 700)  && entrada[6])
				  
    	     {
        		
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView06);
          	   dibujo.setImageResource(imagen(cont_icono_y[6]));
        		
    
    	    	 icono = cont_icono[6];
    	    	 vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[6] = false;
    	    
 	        	    }
        	 
        	 if    (!((event.getX() > 350)  && (event.getX() <525) && (event.getY() > 400 ) && (event.getY() < 700)) )
        	 { ImageView dibujo =  (ImageView) findViewById(R.id.ImageView06);
      	         dibujo.setImageResource(imagen(cont_icono[6]));
        		 entrada[6] = true; }
        	 
        	 /* if (icon.Name.equals("sms"))*/
        	 if ((event.getX() > 525)  && (event.getX() <700) && (event.getY() > 400 ) && (event.getY() < 700)  && entrada[7])
				  
    	     {
        		
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView07);
          	   dibujo.setImageResource(imagen(cont_icono_y[7]));
        		
          	  
        		 
    	    	 icono = cont_icono[7];
    	    	  vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[7] = false;
    	    
 	        	    }
        	 
        	 if    (!((event.getX() > 525)  && (event.getX() <700) && (event.getY() > 400 ) && (event.getY() < 700)) )
		    	 
        	 {	 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView07);
        	 	dibujo.setImageResource(imagen(cont_icono[7]));
        	 	entrada[7] = true; }
        	 
        	 
        	 //*****************************************************************
        	 
        	 
        	 
        	 /*if (icon.Name.equals("store"))*/
        		if ((event.getX() < 175)   && (event.getY() > 700) && (event.getY() < 1000) && entrada[8])
        	     {
        			
        			
        			ImageView dibujo =  (ImageView) findViewById(R.id.ImageView08);
             	   dibujo.setImageResource(imagen(cont_icono_y[8]));
        			
        			
        			
        			 
        	    	 icono = cont_icono[8];
        	    	  vibraciones_iconos(icono);
        	    	 mensaje_pantalla(icono);
        	    	 seleccion_tb(icono);
        	    	 entrada[8] = false;
        	    	
	 	        	    }
        		
        		
        		 
        		   if    (!((event.getX() < 175)  && (event.getY() > 700) && (event.getY() < 1000)) )
        		   {ImageView dibujo =  (ImageView) findViewById(R.id.ImageView08);
            	      dibujo.setImageResource(imagen(cont_icono[8]));
        		    	 entrada[8] = true; }
        		    
        			
          /*  if (icon.Name.equals("talk"))*/
        	
        	if ((event.getX() > 175)  && (event.getX() <350) && (event.getY() > 700) && (event.getY() < 1000) && entrada[9])
        	     {
        		
        		ImageView dibujo =  (ImageView) findViewById(R.id.ImageView09);
         	   dibujo.setImageResource(imagen(cont_icono_y[9]));
        		 
        		 	
        	    	 icono = cont_icono[9];
        	    	  vibraciones_iconos(icono);
        	    	 mensaje_pantalla(icono);
        	    	 seleccion_tb(icono);
        	    	 entrada[9] = false;
	 	        	    }
        	
        	 if    (!((event.getX() > 175)  && (event.getX() <350) && (event.getY() > 700) && (event.getY() < 1000)) )
		    	 {entrada[9] = true;
		    	   ImageView dibujo =  (ImageView) findViewById(R.id.ImageView09);
	        	   dibujo.setImageResource(imagen(cont_icono[9]));
		    	 }
        	 
       	/* if (icon.Name.equals("googleplus")) */
        	if ((event.getX() > 350)  && (event.getX() <525) && (event.getY() > 700) && (event.getY() < 1000) && entrada[10])
    		        
    	     {
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView10);
          	   dibujo.setImageResource(imagen(cont_icono_y[10]));
        		
        		 
    	    	 icono = cont_icono[10];
    	    	  vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[10]= false;
        	 
    	     }
        	
        	 if    (!((event.getX() > 350)  && (event.getX() <525) && (event.getY() > 700) && (event.getY() < 1000)) )
        	 {   ImageView dibujo =  (ImageView) findViewById(R.id.ImageView10);
      	         dibujo.setImageResource(imagen(cont_icono[10]));
        		 entrada[10]= true; }
        	
        	 
    	    	 
      /*  if (icon.Name.equals("wasapp")) */
        	 if ((event.getX() > 525)  && (event.getX() <700) && (event.getY() > 700) && (event.getY() < 1000) && entrada[11])
		    		
    	     {
        	
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView11);
          	   dibujo.setImageResource(imagen(cont_icono_y[11]));
        		
        		 
        		 
    	    	 icono = cont_icono[11];
    	    	 vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[11] = false;
    	    	 
 	        	    }  	     
        		
        	 if    (!((event.getX() > 525)  && (event.getX() <700) && (event.getY() > 700) && (event.getY() < 1000)) )
        	 { ImageView dibujo =  (ImageView) findViewById(R.id.ImageView11);
        	   dibujo.setImageResource(imagen(cont_icono[11]));
        		 entrada[11] = true; }
        	
        	  /*if (icon.Name.equals("calendario"))*/
        	 if ((event.getX() > 0)  && (event.getX() <175) && (event.getY() > 1000 )  && entrada[12])
				  
    	     {
        		 
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView12);
        		 dibujo.setImageResource(imagen(cont_icono_y[12]));
    	    	 
        		 
    	    	 icono = cont_icono[12];
    	    	  vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[12] = false;
    	    
 	        	    }
        	 
        	 if    (!((event.getX() > 0)  && (event.getX() <175) &&  (event.getY() > 1000 ) ) )
        	 { entrada[12]= true; 
          	 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView12);
        	   dibujo.setImageResource(imagen(cont_icono[12]));
        	 }
        	 
        	/* if (icon.Name.equals("camara"))*/
        	 if ((event.getX() > 175)  && (event.getX() <350) &&  (event.getY() > 1000 )  && entrada[13])
				  
    	     {
        		 
        		ImageView dibujo =  (ImageView) findViewById(R.id.ImageView13); 
         		dibujo.setImageResource(imagen(cont_icono_y[13]));
        		    
        		
        		 
    	    	 icono = cont_icono[13];
    	    	  vibraciones_iconos(icono);
    	    	  seleccion_tb(icono);
    	    	 mensaje_pantalla(icono);
    	    	 entrada[13] = false;
    	    
 	        	    }
        	 
        	 
        	 if    (!((event.getX() > 175)  && (event.getX() <350) &&  (event.getY() > 1000 ))) 
        	 {
        		ImageView dibujo =  (ImageView) findViewById(R.id.ImageView13); 
         		dibujo.setImageResource(imagen(cont_icono[13]));
        		entrada[13] = true;} 
        	 
        	 
        	 /* if (icon.Name.equals("reloj"))*/
        	 if ((event.getX() > 350)  && (event.getX() <525) &&  (event.getY() > 1000 )  && entrada[14])
				  
    	     {
        		
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView14);
          	     dibujo.setImageResource(imagen(cont_icono_y[14]));
        		
        		 
        		 
    	    	 icono = cont_icono[14];
    	    	  vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[14] = false;
    	    
 	        	    }
        	 
        	 if    (!((event.getX() > 350)  && (event.getX() <525) &&  (event.getY() > 1000 )) )
        	 { 
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView14);
      	         dibujo.setImageResource(imagen(cont_icono[14]));
		    	 entrada[14] = true; }
        	 
        	 /* if (icon.Name.equals("calculadora"))*/
        	 if ((event.getX() > 525)  && (event.getX() <700) &&  (event.getY() > 1000 )  && entrada[15])
    	     {
        		 
        		ImageView dibujo =  (ImageView) findViewById(R.id.ImageView15); 
        		dibujo.setImageResource(imagen(cont_icono_y[15]));
        		
        		
        		
        		
    	    	 icono = cont_icono[15];
    	    	  vibraciones_iconos(icono);
    	    	 mensaje_pantalla(icono);
    	    	 seleccion_tb(icono);
    	    	 entrada[15] = false;
    	    
 	        	    }
        	 
        	 if    (!((event.getX() > 525)  && (event.getX() <700) &&(event.getY() > 1000 )) )
        	 {
        		 ImageView dibujo =  (ImageView) findViewById(R.id.ImageView15);
        		 entrada[15] = true; 
		    	 dibujo.setImageResource(imagen(cont_icono[15]));
        	 }

		return true;

		}

		
		return false;
		
		
	}
		
		 public void mensaje_pantalla( String texto){
		  		
		   	 /*Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();*/
				  
		 		
		 	}
		 
		 
		 
		 public void seleccion_tb(String icono)
		 
		 {  
			 if (Util.InfoAuditiva) 
			 Util.PlaySound(icono);
		 
			/* try{launcher.stop(); 
	          	 
	          	 launcher.play(3);
    		
    		}catch (Exception e) 
       		{}*/
			 
		 }
		 
		 public void vibraciones_iconos(String haptico)
		 {
			 
			 try{
		        	launcher = new Launcher(this);
		        	launcher.stop();
		        }catch(RuntimeException re){}
			 
			 
			int codigo_vibra =0 ;
			String sonido = "";
			
			 
			 if (haptico == "internet"  )
				 {codigo_vibra = 0;					}
			 if (haptico == "facebook")
			 { codigo_vibra = 3;}
			 if (haptico== "twitter")
			 { codigo_vibra = 24;}
			 if (haptico == "linkedin")
			 { codigo_vibra = 30;}
			 if (haptico == "email")
			 { codigo_vibra = 51;}
			 if (haptico == "line")
			 { codigo_vibra = 60;}
			 if (haptico == "phone")
			 { codigo_vibra = 61;   //duda
			 }
			 if (haptico == "sms"){
				 codigo_vibra = 12; }
			 if (haptico == "store")
				 codigo_vibra = 57;  //duda
			 if (haptico == "talk")
				 codigo_vibra = 36;
			 if (haptico == "googleplus")
				 codigo_vibra = 21;
			 if (haptico == "wasapp")
				 codigo_vibra = 42;
			 if (haptico == "calendario")
				 codigo_vibra = 57;
			 if (haptico == "camara")
				 codigo_vibra = 62;
			 if (haptico == "reloj")
				 codigo_vibra = 15;
			 if (haptico == "calculadora")
				 codigo_vibra = 29;
			
			
			 
				 
				 try{launcher.stop(); 
	          	  /*mediaplayer.start();*/
				    if (Util.DiferIconosHapt){
		          	    launcher.play(codigo_vibra);
					    }else {launcher.play(3);}
	          	    
			
		   	}catch (Exception e) 
	   		{/*(this, "faLLA VIBRACION",
	                Toast.LENGTH_SHORT).show();*/}
				
		 }
		 
		 
		 
		 public boolean onKeyDown(int keyCode, KeyEvent event) {
				// TODO Auto-generated method stub
		 
				switch(keyCode){
					case KeyEvent.KEYCODE_CAMERA:
						/*Toast.makeText(this, "Obturador presionado",
		                                                        Toast.LENGTH_SHORT).show();*/
						return true;
					case KeyEvent.KEYCODE_VOLUME_UP:
						/*Toast.makeText(this, "Boton de Volumen Up presionado",
		                                                        Toast.LENGTH_SHORT).show();*/
						
						/*finish();*/
						Util.PlaySound("cortar");
						Intent intent = new Intent( getApplicationContext(), Seleccion.class);
						startActivity( intent );	
						
						return true;
					case KeyEvent.KEYCODE_VOLUME_DOWN:
						/*Toast.makeText(this, "Boton de Volumen Down presionado",
		                                                        Toast.LENGTH_SHORT).show();*/
						Util.PlaySound("cortar");
						finish();
						return true;
						
					case KeyEvent.KEYCODE_BACK:
						/*Toast.makeText(this, "Boton de Volumen Down presionado",
		                                                        Toast.LENGTH_SHORT).show();*/
						Util.PlaySound("cortar");
						finish();
						return true;
				}
				return super.onKeyDown(keyCode, event);
			}


    
}
